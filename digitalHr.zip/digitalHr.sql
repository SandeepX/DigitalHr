-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 07:15 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE `app_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `app_settings`
--

INSERT INTO `app_settings` (`id`, `name`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(1, 'authorize login', 'authorize-login', 0, NULL, NULL),
(2, 'override bssid', 'override-bssid', 1, NULL, '2023-06-08 11:18:18'),
(3, '24 hour format', '24-hour-format', 0, NULL, NULL),
(4, 'Date In BS', 'bs', 0, NULL, '2023-06-08 11:18:33'),
(5, 'Dark Theme', 'dark-theme', 0, NULL, '2023-05-05 11:17:31');

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) NOT NULL,
  `asset_code` varchar(191) DEFAULT NULL,
  `asset_serial_no` varchar(191) DEFAULT NULL,
  `is_working` varchar(191) NOT NULL DEFAULT 'yes',
  `purchased_date` date NOT NULL,
  `warranty_available` tinyint(1) NOT NULL DEFAULT 0,
  `warranty_end_date` date DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  `assigned_to` bigint(20) UNSIGNED DEFAULT NULL,
  `assigned_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `name`, `type_id`, `image`, `asset_code`, `asset_serial_no`, `is_working`, `purchased_date`, `warranty_available`, `warranty_end_date`, `is_available`, `assigned_to`, `assigned_date`, `note`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(2, 'Dell inspiron', 2, 'Thumb-6454ee1c3e535_Thumb-doctor-20221114111338364.jpg', 'DF1234', '198372MSD', 'yes', '2022-12-01', 1, '2024-05-05', 0, NULL, NULL, '<p>THIS IS TEST COMPUTER&nbsp;</p>', 1, 1, '2023-05-05 11:53:00', '2023-05-07 09:50:06'),
(3, 'Table', 3, 'Thumb-64574a378cfa3_table.png', NULL, NULL, 'maintenance', '2023-05-05', 0, NULL, 1, NULL, NULL, '<p>this is best quality table for receptionist</p>', 1, 1, '2023-05-07 06:50:32', '2023-05-07 07:40:18'),
(4, 'Farrah Gilliam', 3, 'Thumb-645dd02b4d0eb_doctor-20221114110414339.jpg', '276', '190', 'yes', '1977-02-09', 0, NULL, 1, NULL, NULL, '<p>zsadsadasf</p>', 1, 1, '2023-05-12 05:35:39', '2023-05-12 05:35:39');

-- --------------------------------------------------------

--
-- Table structure for table `asset_types`
--

CREATE TABLE `asset_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_types`
--

INSERT INTO `asset_types` (`id`, `name`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(2, 'Electonic v1', 1, 1, 4, '2023-05-03 06:39:58', '2023-05-07 10:20:11'),
(3, 'Furniture', 1, 1, 1, '2023-05-03 06:40:09', '2023-05-05 11:53:39'),
(5, 'Automobile', 1, 1, 1, '2023-05-05 11:54:11', '2023-05-05 11:54:11');

-- --------------------------------------------------------

--
-- Table structure for table `assigned_members`
--

CREATE TABLE `assigned_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED NOT NULL,
  `assignable_type` varchar(191) NOT NULL,
  `assignable_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assigned_members`
--

INSERT INTO `assigned_members` (`id`, `member_id`, `assignable_type`, `assignable_id`) VALUES
(63, 3, 'task', 3),
(64, 4, 'task', 3),
(65, 2, 'task', 3),
(73, 3, 'task', 6),
(128, 4, 'task', 7),
(131, 2, 'task', 5),
(132, 3, 'task', 5),
(154, 2, 'task', 8),
(155, 3, 'task', 8),
(156, 4, 'task', 8),
(187, 4, 'task', 16),
(195, 2, 'task', 9),
(196, 3, 'task', 9),
(268, 2, 'task', 19),
(269, 3, 'task', 19),
(272, 2, 'task', 20),
(273, 3, 'task', 20),
(276, 3, 'task', 22),
(287, 4, 'task', 27),
(288, 5, 'task', 27),
(293, 4, 'task', 28),
(294, 5, 'task', 28),
(298, 2, 'project', 35),
(299, 3, 'project', 35),
(300, 2, 'task', 29),
(349, 2, 'project', 53),
(350, 4, 'project', 53),
(353, 3, 'task', 31),
(354, 2, 'task', 30),
(355, 4, 'task', 30),
(356, 3, 'task', 21),
(358, 3, 'task', 32),
(359, 2, 'task', 33),
(360, 3, 'task', 33),
(362, 4, 'task', 34),
(363, 2, 'project', 54),
(364, 3, 'project', 54),
(365, 2, 'project', 29),
(366, 3, 'project', 29),
(367, 5, 'project', 29),
(370, 4, 'project', 56),
(373, 3, 'project', 34),
(374, 4, 'project', 34),
(375, 5, 'project', 34),
(376, 4, 'project', 58),
(377, 4, 'project', 59),
(378, 2, 'task', 35),
(379, 4, 'task', 35);

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `attachment` varchar(191) NOT NULL,
  `attachment_extension` varchar(191) NOT NULL,
  `attachable_type` varchar(191) NOT NULL,
  `attachable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`id`, `attachment`, `attachment_extension`, `attachable_type`, `attachable_id`, `created_at`, `updated_at`) VALUES
(19, 'Thumb-63ce172a5a122_blog-20220721010104322.jpg', 'jpg', 'task', 9, '2023-01-23 05:12:10', '2023-01-23 05:12:10'),
(20, 'Thumb-63ce172a8119c_blog-20220810021943577.jpg', 'jpg', 'task', 9, '2023-01-23 05:12:10', '2023-01-23 05:12:10'),
(21, '63ce5c4b99685_file-sample_100kB.doc', 'doc', 'task', 9, '2023-01-23 10:07:07', '2023-01-23 10:07:07'),
(22, '63ce5c4b9a03b_chiryau hospital.pdf', 'pdf', 'task', 9, '2023-01-23 10:07:07', '2023-01-23 10:07:07'),
(24, '63d5fed57175d_query.txt', 'txt', 'task', 8, '2023-01-29 05:06:30', '2023-01-29 05:06:30'),
(25, 'Thumb-63d5fed57230b_photo_2022-04-17_13-52-38.jpg', 'jpg', 'task', 8, '2023-01-29 05:06:30', '2023-01-29 05:06:30'),
(26, '63d5fed60aa7d_file-sample_100kB.doc', 'doc', 'task', 8, '2023-01-29 05:06:30', '2023-01-29 05:06:30'),
(27, '63d5fed60acc8_chiryau hospital.pdf', 'pdf', 'task', 8, '2023-01-29 05:06:30', '2023-01-29 05:06:30'),
(28, 'Thumb-63d5fed60ae84_author.jpg', 'jpg', 'task', 8, '2023-01-29 05:06:30', '2023-01-29 05:06:30'),
(31, 'Thumb-63d8f3afbd49b_ban-image2.png', 'png', 'project', 29, '2023-01-31 10:55:44', '2023-01-31 10:55:44'),
(34, '64097bff93b0b_chiryau hospital.pdf', 'pdf', 'task', 30, '2023-03-09 06:26:07', '2023-03-09 06:26:07'),
(36, 'Thumb-64535e9d16ad8_Screenshot 2023-04-05 150455.png', 'png', 'project', 54, '2023-05-04 07:28:29', '2023-05-04 07:28:29'),
(37, 'Thumb-64535eace205a_Screenshot 2023-04-05 150455.png', 'png', 'project', 54, '2023-05-04 07:28:45', '2023-05-04 07:28:45'),
(38, 'Thumb-64535ead0a042_Screenshot 2023-04-18 120313.png', 'png', 'project', 54, '2023-05-04 07:28:45', '2023-05-04 07:28:45'),
(39, 'Thumb-64535ead3b3d0_Screenshot 2023-04-19 155039.png', 'png', 'project', 54, '2023-05-04 07:28:45', '2023-05-04 07:28:45'),
(40, 'Thumb-64535ead63ec5_Screenshot 2023-05-01 174829.png', 'png', 'project', 54, '2023-05-04 07:28:45', '2023-05-04 07:28:45'),
(41, 'Thumb-64535f6ae85d1_Screenshot 2023-04-19 155039.png', 'png', 'project', 54, '2023-05-04 07:31:55', '2023-05-04 07:31:55'),
(42, 'Thumb-64535f75c60de_Screenshot 2023-03-31 115608.png', 'png', 'project', 54, '2023-05-04 07:32:06', '2023-05-04 07:32:06'),
(43, 'Thumb-64535f75f41ff_Screenshot 2023-04-05 150455.png', 'png', 'project', 54, '2023-05-04 07:32:06', '2023-05-04 07:32:06'),
(45, '645368e76dcf1_sample.pdf', 'pdf', 'project', 54, '2023-05-04 08:12:23', '2023-05-04 08:12:23'),
(46, 'Thumb-645368e76e617_Thumb-doctor-20221114111338364.jpg', 'jpg', 'project', 54, '2023-05-04 08:12:23', '2023-05-04 08:12:23'),
(48, 'Thumb-6454d4c2e88c5_doctor-lab-ice-f-2022-01-19-00-12-59-utc.JPG', 'JPG', 'project', 56, '2023-05-05 10:04:51', '2023-05-05 10:04:51'),
(49, 'Thumb-6454d530e2c15_doctor-2021-09-01-12-58-06-utc.jpg', 'jpg', 'task', 31, '2023-05-05 10:06:41', '2023-05-05 10:06:41'),
(50, 'Thumb-6454d6eef172a_happy-woman-and-her-hospitalized-father-talking-to-2022-12-06-01-04-41-utc.jpg', 'jpg', 'task', 32, '2023-05-05 10:14:07', '2023-05-05 10:14:07'),
(51, 'Thumb-6454e143aa323_m-3.jpg', 'jpg', 'task', 33, '2023-05-05 10:58:12', '2023-05-05 10:58:12'),
(52, 'Thumb-6454e1445e5c5_m-4.jpg', 'jpg', 'task', 33, '2023-05-05 10:58:12', '2023-05-05 10:58:12'),
(53, 'Thumb-6454e224c6393_experienced-doctor-2021-08-30-02-07-09-utc.jpg', 'jpg', 'task', 34, '2023-05-05 11:01:57', '2023-05-05 11:01:57'),
(54, 'Thumb-6454e224e7873_happy-woman-and-her-hospitalized-father-talking-to-2022-12-06-01-04-41-utc.jpg', 'jpg', 'task', 34, '2023-05-05 11:01:57', '2023-05-05 11:01:57');

-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

CREATE TABLE `attendances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `attendance_date` date NOT NULL,
  `check_in_at` time NOT NULL,
  `check_out_at` time DEFAULT NULL,
  `check_in_latitude` double DEFAULT NULL,
  `check_out_latitude` double DEFAULT NULL,
  `check_in_longitude` double DEFAULT NULL,
  `check_out_longitude` double DEFAULT NULL,
  `note` text DEFAULT NULL,
  `edit_remark` text DEFAULT NULL,
  `attendance_status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attendances`
--

INSERT INTO `attendances` (`id`, `user_id`, `company_id`, `attendance_date`, `check_in_at`, `check_out_at`, `check_in_latitude`, `check_out_latitude`, `check_in_longitude`, `check_out_longitude`, `note`, `edit_remark`, `attendance_status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(341, 3, 1, '2023-01-09', '10:14:51', '17:48:23', 27.6810604, 27.6819484, 85.3342661, 85.3347817, NULL, NULL, 1, 3, 3, '2023-01-09 10:14:51', '2023-01-09 17:48:23'),
(348, 3, 1, '2023-01-10', '10:05:32', '17:51:33', 27.681057, 27.6810842, 85.3342912, 85.3343014, NULL, NULL, 1, 3, 3, '2023-01-10 10:05:32', '2023-01-10 17:51:33'),
(356, 3, 1, '2023-01-11', '10:10:31', '17:56:26', 27.6810541, 27.6810687, 85.3342732, 85.3342823, NULL, NULL, 1, 3, 3, '2023-01-11 10:10:31', '2023-01-11 17:56:26'),
(363, 3, 1, '2023-01-12', '09:47:40', '17:55:13', 27.6811042, 27.6813046, 85.334269, 85.3339835, NULL, NULL, 1, 3, 3, '2023-01-12 09:47:40', '2023-01-12 17:55:13'),
(373, 3, 1, '2023-01-13', '10:26:46', '17:30:29', 27.6811009, 27.6810851, 85.3342822, 85.334242, NULL, NULL, 1, 3, 3, '2023-01-13 10:26:46', '2023-01-13 17:30:29'),
(381, 3, 1, '2023-01-16', '10:13:45', '17:39:25', 27.6811052, 27.6811151, 85.3342722, 85.334266, NULL, NULL, 1, 3, 3, '2023-01-16 10:13:45', '2023-01-16 17:39:25'),
(387, 3, 1, '2023-01-17', '10:05:00', '18:05:00', 27.6811228, 27.681066, 85.3343106, 85.334218, NULL, 'server issue', 1, 3, 1, '2023-01-17 10:05:37', '2023-01-18 17:47:15'),
(395, 3, 1, '2023-01-18', '09:57:51', '17:55:08', 27.6810965, 27.6811284, 85.3342358, 85.3342822, NULL, NULL, 1, 3, 3, '2023-01-18 09:57:51', '2023-01-18 17:55:08'),
(403, 3, 1, '2023-01-19', '09:57:15', '17:43:36', 27.6815393, 27.6811181, 85.3334898, 85.3343155, NULL, NULL, 1, 3, 3, '2023-01-19 09:57:15', '2023-01-19 17:43:36'),
(409, 3, 1, '2023-01-20', '09:56:13', '17:35:36', 27.6815284, 27.6811589, 85.3331668, 85.334309, NULL, NULL, 1, 3, 3, '2023-01-20 09:56:13', '2023-01-20 17:35:36'),
(418, 3, 1, '2023-01-22', '10:12:58', '18:04:40', 27.6887502, 27.6829477, 85.3700845, 85.3333361, NULL, NULL, 1, 3, 3, '2023-01-22 10:12:58', '2023-01-22 18:04:40'),
(426, 3, 1, '2023-01-23', '10:02:39', '18:05:27', 27.6815393, 27.6810872, 85.3334898, 85.3342773, NULL, NULL, 1, 3, 3, '2023-01-23 10:02:39', '2023-01-23 18:05:27'),
(435, 3, 1, '2023-01-24', '10:01:34', '18:07:02', 27.6810505, 27.6810905, 85.3342474, 85.3342615, NULL, NULL, 1, 3, 3, '2023-01-24 10:01:34', '2023-01-24 18:07:02'),
(441, 3, 1, '2023-01-25', '10:02:38', '16:05:22', 27.6810852, 27.6811046, 85.334252, 85.3342623, NULL, NULL, 1, 3, 3, '2023-01-25 10:02:38', '2023-01-25 16:05:22'),
(455, 3, 1, '2023-01-27', '10:12:51', '17:11:16', 27.6810632, 27.6811022, 85.3342409, 85.3342633, NULL, NULL, 1, 3, 3, '2023-01-27 10:12:51', '2023-01-27 17:11:16'),
(467, 3, 1, '2023-01-29', '11:18:09', '17:25:41', 27.6810425, 27.6810872, 85.3342569, 85.3342682, NULL, NULL, 1, 3, 3, '2023-01-29 11:18:09', '2023-01-29 17:25:41'),
(469, 3, 1, '2023-01-30', '09:51:27', '18:05:48', 27.681053, 27.6810681, 85.3342531, 85.3342589, NULL, NULL, 1, 3, 3, '2023-01-30 09:51:27', '2023-01-30 18:05:48'),
(478, 3, 1, '2023-01-31', '10:09:11', '16:45:57', 27.6823142, 27.6810744, 85.3347817, 85.3342474, NULL, NULL, 1, 3, 3, '2023-01-31 10:09:11', '2023-01-31 16:45:57'),
(485, 3, 1, '2023-02-01', '09:54:35', '18:17:32', 27.6823142, 27.6810582, 85.3347817, 85.3342437, NULL, NULL, 1, 3, 3, '2023-02-01 09:54:35', '2023-02-01 18:17:32'),
(499, 3, 1, '2023-02-02', '10:43:26', '17:41:19', 27.6810477, 27.6810696, 85.3342712, 85.3342494, NULL, NULL, 1, 3, 3, '2023-02-02 10:43:26', '2023-02-02 17:41:19'),
(502, 3, 1, '2023-02-03', '10:09:21', '17:45:37', 27.681048, 27.6810635, 85.3342126, 85.3342525, NULL, NULL, 1, 3, 3, '2023-02-03 10:09:21', '2023-02-03 17:45:37'),
(510, 3, 1, '2023-02-06', '09:55:48', '17:50:05', 27.6809977, 27.6810293, 85.334223, 85.3342043, NULL, NULL, 1, 3, 3, '2023-02-06 09:55:48', '2023-02-06 17:50:05'),
(517, 3, 1, '2023-02-07', '09:58:00', '17:14:31', 27.6815393, 27.6810211, 85.3334898, 85.3342145, NULL, NULL, 1, 3, 3, '2023-02-07 09:58:00', '2023-02-07 17:14:31'),
(525, 3, 1, '2023-02-08', '09:53:26', '18:06:20', 27.6810957, 27.6810199, 85.3342459, 85.3342231, NULL, NULL, 1, 3, 3, '2023-02-08 09:53:26', '2023-02-08 18:06:20'),
(533, 3, 1, '2023-02-09', '10:00:09', '18:05:55', 27.6809946, 27.6810239, 85.3342323, 85.3342677, NULL, NULL, 1, 3, 3, '2023-02-09 10:00:09', '2023-02-09 18:05:55'),
(544, 3, 1, '2023-02-10', '11:04:49', '17:30:38', 27.681, 27.681061, 85.3342208, 85.3343263, NULL, NULL, 1, 3, 3, '2023-02-10 11:04:49', '2023-02-10 17:30:38'),
(547, 3, 1, '2023-02-12', '10:02:14', '18:02:25', 27.6815393, 27.6810368, 85.3334898, 85.3342766, NULL, NULL, 1, 3, 3, '2023-02-12 10:02:14', '2023-02-12 18:02:25'),
(554, 3, 1, '2023-02-13', '10:00:29', '16:57:17', 27.6810764, 27.681081, 85.3343176, 85.3342747, NULL, NULL, 1, 3, 3, '2023-02-13 10:00:29', '2023-02-13 16:57:17'),
(562, 3, 1, '2023-02-14', '10:07:04', '17:26:59', 27.6810076, 27.6810062, 85.3342325, 85.3342145, NULL, NULL, 1, 3, 3, '2023-02-14 10:07:04', '2023-02-14 17:26:59'),
(569, 3, 1, '2023-02-15', '09:50:18', '18:13:51', 27.6809945, 27.6897173, 85.3342267, 85.3883772, NULL, NULL, 1, 3, 3, '2023-02-15 09:50:18', '2023-02-15 18:13:51'),
(579, 3, 1, '2023-02-16', '10:06:38', '17:48:30', 27.6819484, 27.6810026, 85.3347817, 85.3342114, NULL, NULL, 1, 3, 3, '2023-02-16 10:06:38', '2023-02-16 17:48:30'),
(585, 3, 1, '2023-02-17', '10:04:12', '17:34:01', 27.6819051, 27.6810419, 85.3334898, 85.3342181, NULL, NULL, 1, 3, 3, '2023-02-17 10:04:12', '2023-02-17 17:34:01'),
(600, 3, 1, '2023-02-20', '17:20:20', '17:20:28', 27.6810847, 27.6810918, 85.3342929, 85.3342278, NULL, NULL, 1, 3, 3, '2023-02-20 17:20:20', '2023-02-20 17:20:28'),
(602, 3, 1, '2023-02-21', '10:10:20', '17:58:44', 27.6841215, 27.6810484, 85.3341357, 85.3342196, NULL, NULL, 1, 3, 3, '2023-02-21 10:10:20', '2023-02-21 17:58:44'),
(613, 3, 1, '2023-02-22', '10:23:18', '17:41:16', 27.6811737, 27.7438351, 85.3342241, 85.4051016, NULL, NULL, 1, 3, 3, '2023-02-22 10:23:18', '2023-02-22 17:41:16'),
(617, 3, 1, '2023-02-23', '09:59:03', '18:10:40', 27.6944987, 27.6810498, 85.3934533, 85.3342707, NULL, NULL, 1, 3, 3, '2023-02-23 09:59:03', '2023-02-23 18:10:40'),
(625, 3, 1, '2023-02-24', '09:54:28', '17:59:54', 27.6809991, 27.6810296, 85.3342278, 85.3342525, NULL, NULL, 1, 3, 3, '2023-02-24 09:54:28', '2023-02-24 17:59:54'),
(635, 3, 1, '2023-02-26', '10:20:23', '18:06:16', 27.6810761, 27.6810606, 85.3343045, 85.3342905, NULL, NULL, 1, 3, 3, '2023-02-26 10:20:23', '2023-02-26 18:06:16'),
(641, 3, 1, '2023-02-27', '09:56:35', '17:25:02', 27.6809893, 27.6810786, 85.3342181, 85.3342717, NULL, NULL, 1, 3, 3, '2023-02-27 09:56:35', '2023-02-27 17:25:02'),
(651, 3, 1, '2023-02-28', '12:12:32', '18:00:59', 27.6810476, 27.6810759, 85.3342395, 85.3343006, NULL, NULL, 1, 3, 3, '2023-02-28 12:12:32', '2023-02-28 18:00:59'),
(656, 3, 1, '2023-03-01', '10:05:52', '18:00:54', 27.6809889, 27.6810949, 85.3342378, 85.3343204, NULL, NULL, 1, 3, 3, '2023-03-01 10:05:52', '2023-03-01 18:00:54'),
(665, 3, 1, '2023-03-02', '09:57:59', '18:03:01', 27.6811098, 27.6810879, 85.3343489, 85.3342984, NULL, NULL, 1, 3, 3, '2023-03-02 09:57:59', '2023-03-02 18:03:01'),
(672, 3, 1, '2023-03-03', '09:44:20', '17:35:54', 27.6823058, 27.6810648, 85.3555212, 85.3342957, NULL, NULL, 1, 3, 3, '2023-03-03 09:44:20', '2023-03-03 17:35:54'),
(681, 3, 1, '2023-03-07', '09:46:15', '17:58:42', 27.681065, 27.6810937, 85.3343343, 85.3343013, NULL, NULL, 1, 3, 3, '2023-03-07 09:46:15', '2023-03-07 17:58:42'),
(688, 3, 1, '2023-03-08', '09:48:32', '18:08:02', 27.6819484, 27.6810976, 85.3347817, 85.3343279, NULL, NULL, 1, 3, 3, '2023-03-08 09:48:32', '2023-03-08 18:08:02'),
(697, 3, 1, '2023-03-09', '10:02:29', '18:05:46', 27.6815393, 27.6810722, 85.3334898, 85.3343102, NULL, NULL, 1, 3, 3, '2023-03-09 10:02:29', '2023-03-09 18:05:46'),
(711, 3, 1, '2023-03-10', '11:54:26', '17:47:03', 27.6815393, 27.6811003, 85.3334898, 85.3343256, NULL, NULL, 1, 3, 3, '2023-03-10 11:54:26', '2023-03-10 17:47:03'),
(713, 3, 1, '2023-03-12', '10:15:00', '17:43:55', 27.6991581, 27.6819484, 85.3305325, 85.3347817, NULL, NULL, 1, 3, 3, '2023-03-12 10:15:00', '2023-03-12 17:43:55'),
(723, 3, 1, '2023-03-13', '11:11:49', '17:05:35', 27.6810444, 27.6810508, 85.3342383, 85.3342444, NULL, NULL, 1, 3, 3, '2023-03-13 11:11:49', '2023-03-13 17:05:35'),
(729, 3, 1, '2023-03-14', '10:20:17', '16:31:41', 27.6815393, 28.3949, 85.3334898, 84.124, NULL, NULL, 1, 3, 1, '2023-03-14 10:20:17', '2023-03-14 10:46:41'),
(732, 3, 1, '2023-03-15', '08:33:10', '10:48:20', 1231224, 123213213, 3213213, 3213213213, NULL, NULL, 1, 3, 3, '2023-03-15 04:48:10', '2023-03-15 05:03:20'),
(733, 2, 1, '2023-04-28', '12:29:30', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-04-28 06:44:30', '2023-04-28 06:44:30'),
(735, 3, 1, '2023-04-28', '12:31:41', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-04-28 06:46:41', '2023-04-28 06:46:41'),
(736, 4, 1, '2023-04-28', '12:33:24', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-04-28 06:48:24', '2023-04-28 06:48:24'),
(835, 4, 1, '2023-05-01', '17:28:29', '17:28:34', 28.3949, 28.3949, 84.124, 84.124, NULL, NULL, 1, 4, 4, '2023-05-01 11:43:29', '2023-05-01 11:43:34'),
(848, 1, 1, '2023-05-03', '13:59:31', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-05-03 08:14:31', '2023-05-03 08:14:31'),
(850, 1, 1, '2023-05-04', '14:00:33', '14:00:35', 28.3949, 28.3949, 84.124, 84.124, NULL, NULL, 1, 1, 1, '2023-05-04 08:15:33', '2023-05-04 08:15:35'),
(855, 1, 1, '2023-05-05', '17:56:47', '17:56:50', 28.3949, 28.3949, 84.124, 84.124, NULL, NULL, 1, 1, 1, '2023-05-05 12:11:47', '2023-05-05 12:11:50'),
(856, 1, 1, '2023-05-11', '22:54:00', '16:54:58', 28.3949, 28.3949, 84.124, 84.124, NULL, 'saSAsASAsaSAsasadsasd', 1, 1, 1, '2023-05-11 11:09:23', '2023-05-11 11:09:58'),
(857, 2, 1, '2023-05-11', '16:54:29', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-05-11 11:09:29', '2023-05-11 11:09:29'),
(858, 3, 1, '2023-05-11', '16:54:32', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-05-11 11:09:32', '2023-05-11 11:09:32'),
(862, 1, 1, '2023-05-12', '11:23:00', '15:43:11', 28.3949, 28.3949, 84.124, 84.124, NULL, 'not checkout', 1, 1, 1, '2023-05-12 05:38:07', '2023-05-12 09:58:11'),
(863, 2, 1, '2023-05-12', '11:23:11', '16:50:19', 28.3949, 28.3949, 84.124, 84.124, NULL, NULL, 1, 1, 1, '2023-05-12 05:38:11', '2023-05-12 11:05:19'),
(864, 3, 1, '2023-05-12', '11:23:16', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-05-12 05:38:16', '2023-05-12 05:38:16'),
(865, 4, 1, '2023-05-12', '11:23:19', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-05-12 05:38:19', '2023-05-12 05:38:19'),
(866, 5, 1, '2023-05-12', '11:23:23', NULL, 28.3949, NULL, 84.124, NULL, NULL, NULL, 1, 1, NULL, '2023-05-12 05:38:23', '2023-05-12 05:38:23'),
(897, 1, 1, '2023-06-08', '17:02:52', '17:02:53', 27.681114084731657, 27.681114084731657, 85.33416547358728, 85.33416547358728, NULL, NULL, 1, 1, 1, '2023-06-08 11:17:52', '2023-06-08 11:17:53'),
(898, 2, 1, '2023-06-08', '17:20:18', '17:20:22', 28.3949, 28.3949, 84.124, 84.124, NULL, NULL, 1, 1, 1, '2023-06-08 11:35:18', '2023-06-08 11:35:22');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `address` varchar(191) NOT NULL,
  `phone` varchar(191) NOT NULL,
  `branch_head_id` bigint(20) UNSIGNED DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `branch_location_latitude` double DEFAULT NULL,
  `branch_location_longitude` double DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `name`, `address`, `phone`, `branch_head_id`, `company_id`, `branch_location_latitude`, `branch_location_longitude`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'kathmandu', 'Nepal', '9812604223', 1, 1, 28.3949, 84.124, 1, 1, 1, '2023-01-04 05:58:27', '2023-01-04 05:58:27'),
(2, 'Prithvi Branch', 'Pokhara ,Nepal', '9812604221', 2, 1, 28.2096, 83.9856, 1, 1, 1, '2023-01-04 11:04:42', '2023-01-04 11:04:42');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(191) NOT NULL,
  `contact_no` varchar(191) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` varchar(191) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `email`, `contact_no`, `avatar`, `address`, `country`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(5, 'Helmate Nepal', 'nepal@gmail.com', '9800112233', 'Thumb-63d8b34e378c3_13 [Converted]-03.png', 'kathmandu', 'Nepal', 1, 4, 4, '2023-01-31 06:21:02', '2023-01-31 06:21:02'),
(6, 'Chirayu Hospital', 'chiratya@gmail.com', '9812604223', 'Thumb-63d8b36fbe9f3_photo_2022-04-17_13-52-38.jpg', 'kathamdnu', 'Nepal', 1, 4, 4, '2023-01-31 06:21:36', '2023-01-31 06:21:36'),
(21, 'sandeep', 'sandeep@gmail.com', '9812333309', 'Thumb-63d9016d148d4_photo_2022-04-17_13-52-38.jpg', 'kathmandu', 'Nepal', 1, 4, 4, '2023-01-31 11:54:21', '2023-01-31 11:54:21'),
(23, 'Keshav', 'bahtt@gmail.com', '9807111111', 'Thumb-63d90272b0c92_photo_2022-04-17_13-52-38.jpg', 'London', 'England', 1, 4, 4, '2023-01-31 11:58:42', '2023-01-31 12:00:11'),
(25, 'Samin', 'sadsad@gmail.com', '12321321', 'Thumb-63da2abc94a97_photo_2022-04-17_13-52-38.jpg', 'adasd', 'adasd', 1, 4, 4, '2023-02-01 09:02:52', '2023-02-01 09:02:52'),
(26, 'test client', 'client@gmail.com', '9812213213', 'Thumb-63da2b05e32ce_photo_2022-04-17_13-52-38.jpg', 'asdasd', 'nepal', 1, 4, 4, '2023-02-01 09:04:06', '2023-02-01 09:04:06'),
(27, 'Epic Event', 'sa@cc.cc', 'fdfdsfsfds', 'Thumb-6454d041a2d17_01_epicevent_thumnail.png', '100m ahead from Amar Shishu Vidyalaya, ललितपुर', 'Nepal', 1, 1, 1, '2023-05-05 09:45:37', '2023-05-05 09:45:37'),
(28, 'Lorem ipsum', 'sas@cc.ccc', 'er6t4t3643665464', 'Thumb-6454d5b8d9670_doctor-2021-09-01-12-58-06-utc1.png', 'efefsf afafafasfasfas', 'Estonia', 1, 1, 1, '2023-05-05 10:08:57', '2023-05-05 10:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `comment_replies`
--

CREATE TABLE `comment_replies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `description` text NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comment_replies`
--

INSERT INTO `comment_replies` (`id`, `description`, `comment_id`, `created_by`, `created_at`, `updated_at`) VALUES
(21, 'ok replied', 23, 1, '2023-02-03 10:05:31', '2023-02-03 10:05:31'),
(31, 'fxfdzfdfd', 49, 1, '2023-04-24 10:43:44', '2023-04-24 10:43:44'),
(32, 'oky let it be mine asdsadasdsad', 51, 4, '2023-04-24 10:53:39', '2023-04-24 10:53:39'),
(33, 'fdfsdfdsf', 52, 1, '2023-04-24 11:06:47', '2023-04-24 11:06:47'),
(34, 'oky let it be mine asdsadasdsad', 51, 4, '2023-05-12 07:31:25', '2023-05-12 07:31:25'),
(35, 'dsadasdasdsad', 74, 1, '2023-05-12 10:57:14', '2023-05-12 10:57:14'),
(36, 'dsadasdasdsad', 74, 1, '2023-05-12 11:00:40', '2023-05-12 11:00:40'),
(37, 'dsadasdasdsad', 74, 1, '2023-05-12 11:02:05', '2023-05-12 11:02:05'),
(38, 'dsadasdasdsad', 74, 1, '2023-05-12 11:04:40', '2023-05-12 11:04:40');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `owner_name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(191) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `website_url` text DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `weekend` varchar(191) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `owner_name`, `email`, `address`, `phone`, `is_active`, `website_url`, `logo`, `weekend`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Cyclone Nepal INfoTech', 'Santosh Maharjan', 'info@cninfotehc.com', 'Shankhmul', '9803022718', 1, 'http://127.0.0.1:8000/admin/company', 'Thumb-6454a67a9509f_logo.png', '[\"4\",\"6\"]', NULL, 1, '2022-12-29 11:05:43', '2023-06-04 07:42:28');

-- --------------------------------------------------------

--
-- Table structure for table `company_content_management`
--

CREATE TABLE `company_content_management` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` text NOT NULL,
  `title_slug` varchar(191) NOT NULL,
  `content_type` varchar(191) NOT NULL,
  `description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `company_content_management`
--

INSERT INTO `company_content_management` (`id`, `title`, `title_slug`, `content_type`, `description`, `is_active`, `company_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'privacy policy', 'privacy-policy', 'app-policy', '<p>Vivamus suscipit tortor eget felis porttitor volutpat. Proin eget tortor risus. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Nulla porttitor accumsan tincidunt. Donec rutrum congue leo eget malesuada. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Proin eget tortor risus. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.</p>\r\n<p>Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Cras ultricies ligula sed magna dictum porta. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit.</p>\r\n<p>Proin eget tortor risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor lectus nibh. Donec rutrum congue leo eget malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec rutrum congue leo eget malesuada.</p>\r\n<p>Nulla porttitor accumsan tincidunt. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Donec sollicitudin molestie malesuada. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Cras ultricies ligula sed magna dictum porta. Donec rutrum congue leo eget malesuada. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh.</p>\r\n<p>Donec rutrum congue leo eget malesuada. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Proin eget tortor risus. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Cras ultricies ligula sed magna dictum porta. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Proin eget tortor risus. Nulla quis lorem ut libero malesuada feugiat.</p>', 1, 1, 4, NULL, '2023-01-11 11:16:34', '2023-01-11 11:16:34');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dept_name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `address` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `dept_head_id` bigint(20) UNSIGNED DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `branch_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `dept_name`, `slug`, `address`, `phone`, `is_active`, `dept_head_id`, `company_id`, `branch_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'IT Department', 'it-department', 'Kathmandu Maitighar', '9812111111', 1, 1, 1, 1, 1, 1, '2023-01-04 05:59:05', '2023-01-04 05:59:05'),
(2, 'Sales And Marketing', 'sales-and-marketing', 'Kathamdnu', '9822324553', 1, 3, 1, 1, 1, 1, '2023-01-04 11:03:18', '2023-01-04 11:03:18');

-- --------------------------------------------------------

--
-- Table structure for table `employee_accounts`
--

CREATE TABLE `employee_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `bank_name` varchar(191) DEFAULT NULL,
  `bank_account_no` text DEFAULT NULL,
  `bank_account_type` varchar(191) DEFAULT NULL,
  `salary` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `key` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `name`, `type`, `key`, `value`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Firebase Key', 'configuration', 'firebase_key', 'AAAAO21xPvU:APA91bFbZaScwcv-Uau2yeoGHjAqrJlICq_tPO2zx_TlFB9B2h5O1GqqtMkUMnM-Ks2u5UH7GKBaJ75kn5jm1nLuIqyCWNg1VTIO84NOjsnmuyhKBVcc5IWiAejRGgLcEL6Fbsx5Q1lU', 'Firebase key is needed to send notification in mobile.', NULL, NULL),
(2, 'Set Number Of Days for local Push Notification', 'configuration', 'attendance_notify', '7', 'Setting no of days will automatically send the data of those days to the mobile application.Receiving this data on the mobile end will allow the mobile application to set local push notification for those dates. The local push notification will help employees remember to check in on time as well as to check out when the shift is about to end.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `event` varchar(191) NOT NULL,
  `event_date` date NOT NULL,
  `note` longtext DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`id`, `event`, `event_date`, `note`, `is_active`, `company_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'maghey sharkariti', '2023-01-15', 'sunday leave', 1, 1, 1, 1, '2023-01-09 06:14:50', '2023-01-09 06:14:50'),
(4, 'Sunday Leave', '2023-03-05', NULL, 1, 1, 1, 1, '2023-03-01 06:49:47', '2023-03-01 06:58:49'),
(5, 'Holi Festival', '2023-03-06', '<p>this is holiday for holi enojy</p>', 1, 1, 1, 1, '2023-03-01 06:53:22', '2023-03-01 06:56:49'),
(6, 'Cristmas', '2022-12-25', NULL, 1, 1, 1, 1, '2023-03-01 08:09:36', '2023-03-01 08:09:36'),
(7, 'Cristmas', '2023-05-10', NULL, 1, 1, 1, 1, '2023-03-01 08:09:36', '2023-03-01 08:09:36');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(1, 'default', '{\"uuid\":\"102d47b0-b40d-420d-b0a5-e2930b866857\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:4;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"7971e59781b02411237919cb2abd0701af8483a6c4192dfd03e0214fdccc68ce\\\";s:2:\\\"id\\\";s:36:\\\"8f863b36-d110-4b0a-af47-d20872f87c15\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686048337, 1686048337),
(2, 'default', '{\"uuid\":\"0cad8219-3c3f-48e8-99df-7b08c7041086\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:4;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"2771a0df5053cb45a8c10cacacb7deb32b42fc4dd2324e8ec6d939863ea1ce2d\\\";s:2:\\\"id\\\";s:36:\\\"dce1724e-6705-4b3e-9887-0242dfd0d0c9\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686048439, 1686048439),
(3, 'default', '{\"uuid\":\"395b5a45-ef4b-450e-a48a-c069ea3492eb\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"f0ce435eaf4945b172b8249c5c8024341b12b83345567c09117d78402a3e9c6d\\\";s:2:\\\"id\\\";s:36:\\\"50529927-1f6a-47d9-bcbd-63e02adae73d\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686048512, 1686048512),
(4, 'default', '{\"uuid\":\"753699f8-76c7-49ca-baef-50d37aeb9fd4\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"4c306924dc12f02981ec0b799502e6bc9d86bdb2c12354d6813641dc89b8c9e1\\\";s:2:\\\"id\\\";s:36:\\\"29bc76cd-3c3a-492c-a532-dfa68163cd6f\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686048639, 1686048639),
(5, 'default', '{\"uuid\":\"e23ddf62-9270-4a2c-ab4f-469d954de3c7\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"04fcec02c8b445478e4897cfbdc285c137626944d630e6fc85379deb6fd87c2f\\\";s:2:\\\"id\\\";s:36:\\\"6dca1be7-c1be-4aff-860e-91ae6ee75f2b\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686048732, 1686048732),
(6, 'default', '{\"uuid\":\"cb0992f1-ba0d-485a-97f5-c65419b95785\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"bdc169ac0ae66a259db8a8defecea47cf6d82fbc8bf706cfdcbc3b6139549614\\\";s:2:\\\"id\\\";s:36:\\\"e07b44b8-a325-4f9c-b137-bb182d2e5c79\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686049053, 1686049053),
(7, 'default', '{\"uuid\":\"20f745da-8482-49c3-935a-c90f2795bf13\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"af7c9a09949255b2de28f2f94f31efa2a21748f0d598d1733ddb631a645f200c\\\";s:2:\\\"id\\\";s:36:\\\"f375da99-131e-463b-b4e2-2e4de7051691\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686049163, 1686049163),
(8, 'default', '{\"uuid\":\"29b7eec8-8a53-425b-851b-bee8b61ede08\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"fef1d96c9323a255c89708f2020d39003887f9bea1ad27ddb656b00a9ab144f2\\\";s:2:\\\"id\\\";s:36:\\\"d39f4369-ebab-4f4b-90be-485afd59a5c0\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686049406, 1686049406),
(9, 'default', '{\"uuid\":\"057d79ea-bbfe-46da-9feb-e2468f11eba4\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"f15221f2570889a8167ce7eaad824c375911d6aff65b62e46aea2e66fc354ad2\\\";s:2:\\\"id\\\";s:36:\\\"5a3ab010-0283-4fb9-914f-0bd349979a8b\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686049706, 1686049706),
(10, 'default', '{\"uuid\":\"52b21953-4e3e-499e-ad79-053026437302\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"7a92160b2f17a5e71419c17d1cea1db434a2fca063c639c17bbe5b737628cc81\\\";s:2:\\\"id\\\";s:36:\\\"5c9b4938-0426-4ac9-a170-99c5238b80c3\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686053062, 1686053062),
(11, 'default', '{\"uuid\":\"42febb2b-5ecc-4518-83be-f176039927b8\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"caebc1731ac86f940f8984c128d598eb084c17ed9ff49c552900f51323624ee9\\\";s:2:\\\"id\\\";s:36:\\\"9345167f-1679-435f-89fe-bdacf3a011e7\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686053397, 1686053397),
(12, 'default', '{\"uuid\":\"9491ee96-5def-431b-bc26-07f46b6275ea\",\"displayName\":\"App\\\\Notifications\\\\ResetPasswordNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\ResetPasswordNotification\\\":2:{s:5:\\\"token\\\";s:64:\\\"88afeb08c5f933bd159776f7d91a4596544f1b04a9cf60c743cdc276eb7a3ed5\\\";s:2:\\\"id\\\";s:36:\\\"0490853a-99b9-4165-b600-67b43bb152eb\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}', 0, NULL, 1686053631, 1686053631);

-- --------------------------------------------------------

--
-- Table structure for table `leave_requests_master`
--

CREATE TABLE `leave_requests_master` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `leave_type_id` bigint(20) UNSIGNED NOT NULL,
  `leave_requested_date` datetime NOT NULL,
  `leave_from` datetime NOT NULL,
  `leave_to` datetime NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'pending',
  `reasons` longtext NOT NULL,
  `admin_remark` longtext DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `requested_by` bigint(20) UNSIGNED NOT NULL,
  `early_exit` tinyint(1) NOT NULL DEFAULT 0,
  `request_updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_requests_master`
--

INSERT INTO `leave_requests_master` (`id`, `no_of_days`, `leave_type_id`, `leave_requested_date`, `leave_from`, `leave_to`, `status`, `reasons`, `admin_remark`, `company_id`, `requested_by`, `early_exit`, `request_updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2023-01-13 14:53:37', '2023-02-09 08:30:34', '2023-02-09 03:30:34', 'cancelled', 'this is it', NULL, 1, 4, 0, 4, '2023-01-13 06:08:37', '2023-05-08 08:29:58'),
(2, 1, 1, '2023-01-13 11:55:40', '2023-02-08 08:30:34', '2023-02-08 09:30:37', 'approved', 'this is it', NULL, 1, 4, 0, 1, '2023-01-13 06:10:40', '2023-05-12 07:19:03'),
(3, 1, 1, '2022-04-14 11:53:37', '2023-02-09 08:30:34', '2023-02-09 03:30:34', 'approved', 'this is it', NULL, 1, 4, 0, 1, '2023-01-13 06:08:37', '2023-02-21 06:18:19'),
(4, 4, 2, '2022-03-14 11:53:37', '2022-03-15 08:30:34', '2022-03-17 03:30:34', 'approved', 'this is it', NULL, 1, 4, 0, 1, '2023-04-13 06:08:37', '2023-04-21 06:18:19'),
(5, 1, 1, '2023-03-02 11:53:37', '2023-03-03 08:30:34', '2023-03-03 11:30:34', 'approved', 'this is it', NULL, 1, 4, 0, 1, '2023-04-13 06:08:37', '2023-04-21 06:18:19'),
(6, 1, 2, '2023-03-01 11:53:37', '2023-03-01 08:30:34', '2023-03-01 11:30:34', 'approved', 'this is it', NULL, 1, 4, 0, 1, '2023-04-13 06:08:37', '2023-04-21 06:18:19'),
(7, 1, 1, '2023-03-02 11:53:37', '2023-03-02 08:30:34', '2023-03-02 11:30:34', 'approved', 'this is it', NULL, 1, 4, 0, 1, '2023-04-13 06:08:37', '2023-04-21 06:18:19'),
(8, 1, 1, '2023-05-31 05:19:34', '2023-06-01 17:19:34', '2023-06-01 17:19:34', 'pending', 'thit si test leave', NULL, 1, 1, 1, NULL, '2023-05-31 11:34:34', '2023-05-31 11:34:34'),
(9, 1, 1, '2023-06-08 05:02:43', '2023-09-08 17:02:43', '2023-09-08 17:02:43', 'pending', 'Autem nulla voluptat', NULL, 1, 1, 1, NULL, '2023-06-08 11:17:43', '2023-06-08 11:17:43');

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE `leave_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `leave_allocated` int(11) DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `early_exit` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`id`, `name`, `slug`, `leave_allocated`, `company_id`, `is_active`, `early_exit`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'sick leave', 'sick-leave', 6, 1, 1, 1, 1, 1, '2023-01-04 06:01:50', '2023-05-30 06:18:42'),
(2, 'urgent leave', 'urgent-leave', 6, 1, 1, 1, 1, 1, '2023-03-02 05:36:49', '2023-05-30 06:34:41'),
(3, 'test leave', 'test-leave', NULL, 1, 1, 0, 1, NULL, '2023-03-02 05:58:42', '2023-03-02 05:58:42'),
(5, 'Maternity Leave', 'maternity-leave', 20, 1, 1, 0, 1, NULL, '2023-05-05 11:42:16', '2023-05-05 11:42:16');

-- --------------------------------------------------------

--
-- Table structure for table `mentioned_comment_members`
--

CREATE TABLE `mentioned_comment_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `member_id` bigint(20) UNSIGNED NOT NULL,
  `mentionable_type` varchar(191) NOT NULL,
  `mentionable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mentioned_comment_members`
--

INSERT INTO `mentioned_comment_members` (`id`, `member_id`, `mentionable_type`, `mentionable_id`, `created_at`, `updated_at`) VALUES
(33, 2, 'comment', 23, '2023-02-01 11:05:04', '2023-02-01 11:05:04'),
(34, 5, 'comment', 24, '2023-02-17 07:01:31', '2023-02-17 07:01:31'),
(35, 2, 'comment', 25, '2023-02-21 06:06:32', '2023-02-21 06:06:32'),
(36, 4, 'comment', 28, '2023-04-24 08:49:39', '2023-04-24 08:49:39'),
(37, 2, 'comment', 30, '2023-04-24 08:53:29', '2023-04-24 08:53:29'),
(43, 4, 'comment', 40, '2023-04-24 09:29:11', '2023-04-24 09:29:11'),
(44, 4, 'comment', 41, '2023-04-24 09:29:22', '2023-04-24 09:29:22'),
(45, 2, 'reply', 23, '2023-04-24 09:30:07', '2023-04-24 09:30:07'),
(46, 2, 'comment', 42, '2023-04-24 09:32:11', '2023-04-24 09:32:11'),
(47, 2, 'reply', 24, '2023-04-24 09:33:57', '2023-04-24 09:33:57'),
(48, 2, 'reply', 25, '2023-04-24 09:34:04', '2023-04-24 09:34:04'),
(49, 4, 'comment', 44, '2023-04-24 09:34:50', '2023-04-24 09:34:50'),
(50, 2, 'reply', 26, '2023-04-24 10:05:55', '2023-04-24 10:05:55'),
(51, 4, 'reply', 26, '2023-04-24 10:05:55', '2023-04-24 10:05:55'),
(52, 2, 'reply', 27, '2023-04-24 10:06:19', '2023-04-24 10:06:19'),
(53, 4, 'reply', 27, '2023-04-24 10:06:19', '2023-04-24 10:06:19'),
(54, 2, 'reply', 28, '2023-04-24 10:06:28', '2023-04-24 10:06:28'),
(55, 4, 'reply', 28, '2023-04-24 10:06:28', '2023-04-24 10:06:28'),
(56, 4, 'reply', 29, '2023-04-24 10:32:59', '2023-04-24 10:32:59'),
(57, 2, 'reply', 30, '2023-04-24 10:33:08', '2023-04-24 10:33:08'),
(58, 4, 'reply', 30, '2023-04-24 10:33:08', '2023-04-24 10:33:08'),
(59, 2, 'comment', 46, '2023-04-24 10:35:19', '2023-04-24 10:35:19'),
(60, 4, 'comment', 46, '2023-04-24 10:35:19', '2023-04-24 10:35:19'),
(61, 2, 'comment', 47, '2023-04-24 10:35:26', '2023-04-24 10:35:26'),
(62, 4, 'comment', 47, '2023-04-24 10:35:26', '2023-04-24 10:35:26'),
(63, 2, 'comment', 48, '2023-04-24 10:41:51', '2023-04-24 10:41:51'),
(64, 4, 'comment', 48, '2023-04-24 10:41:51', '2023-04-24 10:41:51'),
(65, 2, 'comment', 49, '2023-04-24 10:43:24', '2023-04-24 10:43:24'),
(66, 4, 'comment', 49, '2023-04-24 10:43:24', '2023-04-24 10:43:24'),
(67, 4, 'reply', 31, '2023-04-24 10:43:44', '2023-04-24 10:43:44'),
(68, 4, 'comment', 50, '2023-04-24 10:50:20', '2023-04-24 10:50:20'),
(69, 4, 'comment', 51, '2023-04-24 10:53:29', '2023-04-24 10:53:29'),
(70, 4, 'reply', 32, '2023-04-24 10:53:39', '2023-04-24 10:53:39'),
(71, 4, 'reply', 33, '2023-04-24 11:06:47', '2023-04-24 11:06:47'),
(72, 4, 'comment', 63, '2023-04-24 11:18:34', '2023-04-24 11:18:34'),
(73, 4, 'comment', 64, '2023-04-24 11:18:42', '2023-04-24 11:18:42'),
(74, 2, 'comment', 67, '2023-04-24 11:19:55', '2023-04-24 11:19:55'),
(75, 3, 'comment', 71, '2023-05-05 10:07:42', '2023-05-05 10:07:42'),
(76, 4, 'reply', 34, '2023-05-12 07:31:25', '2023-05-12 07:31:25'),
(77, 4, 'comment', 72, '2023-05-12 07:32:11', '2023-05-12 07:32:11'),
(78, 4, 'comment', 73, '2023-05-12 07:32:25', '2023-05-12 07:32:25'),
(79, 4, 'comment', 74, '2023-05-12 10:00:48', '2023-05-12 10:00:48'),
(80, 4, 'comment', 75, '2023-05-12 10:00:58', '2023-05-12 10:00:58'),
(81, 4, 'comment', 76, '2023-05-12 10:01:52', '2023-05-12 10:01:52'),
(82, 4, 'comment', 77, '2023-05-12 10:01:59', '2023-05-12 10:01:59'),
(83, 4, 'comment', 78, '2023-05-12 10:03:25', '2023-05-12 10:03:25'),
(84, 4, 'comment', 79, '2023-05-12 10:03:52', '2023-05-12 10:03:52'),
(85, 4, 'comment', 80, '2023-05-12 10:04:51', '2023-05-12 10:04:51'),
(86, 4, 'comment', 81, '2023-05-12 10:05:11', '2023-05-12 10:05:11'),
(88, 4, 'comment', 83, '2023-05-12 10:36:01', '2023-05-12 10:36:01'),
(89, 4, 'comment', 84, '2023-05-12 10:38:30', '2023-05-12 10:38:30'),
(90, 4, 'comment', 85, '2023-05-12 10:40:38', '2023-05-12 10:40:38'),
(91, 4, 'comment', 86, '2023-05-12 10:40:57', '2023-05-12 10:40:57'),
(92, 4, 'comment', 87, '2023-05-12 10:41:08', '2023-05-12 10:41:08'),
(93, 4, 'comment', 88, '2023-05-12 10:41:34', '2023-05-12 10:41:34'),
(94, 4, 'comment', 89, '2023-05-12 10:44:13', '2023-05-12 10:44:13'),
(95, 4, 'reply', 35, '2023-05-12 10:57:14', '2023-05-12 10:57:14'),
(96, 4, 'reply', 36, '2023-05-12 11:00:40', '2023-05-12 11:00:40'),
(97, 4, 'reply', 37, '2023-05-12 11:02:05', '2023-05-12 11:02:05'),
(98, 4, 'reply', 38, '2023-05-12 11:04:40', '2023-05-12 11:04:40');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(10, '2022_06_13_090431_create_companies_table', 1),
(11, '2022_06_14_063357_create_branches_table', 1),
(12, '2022_06_15_071047_create_departments_table', 1),
(13, '2022_06_15_112610_create_posts_table', 1),
(14, '2022_06_16_070711_create_roles_table', 1),
(15, '2022_06_16_093102_create_office_times_table', 1),
(16, '2022_06_17_061319_create_routers_table', 1),
(17, '2022_06_17_085607_create_holidays_table', 1),
(18, '2022_06_20_053339_add_new_columns_in_users_table', 1),
(19, '2022_06_21_101228_create_app_settings_table', 1),
(20, '2022_06_23_075347_create_leave_types_table', 1),
(21, '2022_06_24_061745_leave_requests_master', 1),
(22, '2022_06_24_101935_create_company_content_management_table', 1),
(23, '2022_06_27_044234_create_notifications_table', 1),
(24, '2022_06_28_122815_create_attendances_table', 1),
(25, '2022_07_26_102506_create_jobs_table', 1),
(26, '2022_08_01_102650_create_notices_table', 1),
(27, '2022_08_01_103953_create_notice_users_table', 1),
(28, '2022_08_03_144251_create_team_meetings_table', 1),
(29, '2022_08_03_145534_create_team_meeting_members_table', 1),
(30, '2022_09_22_124231_create_general_settings_table', 1),
(38, '2023_01_04_135032_create_clients_table', 2),
(39, '2023_01_04_140527_create_projects_table', 2),
(40, '2023_01_04_140730_create_assigned_members_table', 2),
(42, '2023_01_04_140818_create_tasks_table', 3),
(43, '2023_01_05_104631_create_task_checklists_table', 4),
(44, '2023_01_05_122340_create_project_team_leaders_table', 5),
(45, '2016_06_01_000001_create_oauth_auth_codes_table', 6),
(46, '2016_06_01_000002_create_oauth_access_tokens_table', 6),
(47, '2016_06_01_000003_create_oauth_refresh_tokens_table', 6),
(48, '2016_06_01_000004_create_oauth_clients_table', 6),
(49, '2016_06_01_000005_create_oauth_personal_access_clients_table', 6),
(50, '2019_12_14_000001_create_personal_access_tokens_table', 6),
(52, '2023_01_22_143941_create_attachments_table', 8),
(56, '2023_01_23_152239_create_task_comments_table', 9),
(57, '2023_01_23_152738_create_mentioned_comment_members_table', 9),
(58, '2023_01_23_153404_create_commet_replies_table', 9),
(59, '2023_01_29_133948_create_supports_table', 10),
(60, '2023_02_02_111443_add_new_columns_in_supports_table', 11),
(61, '2023_02_06_104724_create_tadas_table', 12),
(62, '2023_02_06_112958_create_tada_attachments_table', 12),
(64, '2023_02_20_130957_add_new_columns_in_notifications_table', 13),
(65, '2023_02_20_132231_create_user_notifications_table', 14),
(66, '2023_04_12_140511_create_permission_groups_table', 15),
(67, '2023_04_12_140523_create_permissions_table', 15),
(68, '2023_04_12_140535_create_permission_roles_table', 15),
(69, '2023_04_19_145742_add_new_column_backend_login_authorize_to_roles_table', 15),
(70, '2023_04_26_104200_create_permission_group_types_table', 16),
(71, '2023_04_26_104646_add_new_column_permission_group_type_in_permission_group_table', 16),
(72, '2023_05_03_103931_create_asset_types_table', 17),
(74, '2023_05_04_104341_create_assets_table', 18),
(75, '2023_05_19_125923_alter_data_type_of_name_in_tasks_table', 19),
(76, '2023_05_23_114903_add_new_column_in_supports', 19),
(77, '2023_05_25_145139_add_new_column_description', 19),
(80, '2023_06_01_103553_create_employee_accounts_table', 20),
(81, '2023_06_01_110004_drop_bank_detail_columns_from_user_table', 20),
(82, '2023_06_02_102926_create_salary_components_table', 21),
(83, '2023_06_02_153355_create_payment_methods_table', 22),
(84, '2023_06_04_131357_create_payment_currencies_table', 23),
(86, '2023_06_04_163544_create_salary_t_d_s_table', 24),
(87, '2023_06_06_104256_add_new_column_marital_status_in_users_table', 25),
(88, '2023_06_06_131847_create_salary_groups_table', 26),
(89, '2023_06_06_132126_create_salary_group_component_table', 26),
(90, '2023_06_07_131523_create_salary_group_employees_table', 27);

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` longtext NOT NULL,
  `notice_publish_date` datetime NOT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `title`, `description`, `notice_publish_date`, `company_id`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Quidem tempor doloru', 'Ad vel ea sit doloredfdfsdfdsf', '2023-03-02 10:34:04', 1, 1, 1, NULL, '2023-03-03 04:49:04', '2023-03-03 04:49:04'),
(2, 'Tempora ratione fugi', 'Eiusmod animi maxim', '2023-03-03 13:25:59', 1, 1, 1, 1, '2023-03-03 04:49:17', '2023-03-03 07:40:59');

-- --------------------------------------------------------

--
-- Table structure for table `notice_receivers`
--

CREATE TABLE `notice_receivers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notice_id` bigint(20) UNSIGNED NOT NULL,
  `notice_receiver_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notice_receivers`
--

INSERT INTO `notice_receivers` (`id`, `notice_id`, `notice_receiver_id`) VALUES
(1, 1, 2),
(2, 1, 5),
(5, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` longtext NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'general',
  `notification_publish_date` datetime NOT NULL,
  `notification_for_id` bigint(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `description`, `type`, `notification_publish_date`, `notification_for_id`, `is_active`, `company_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'this is test for edit', 'Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttito', 'general', '2023-02-21 16:52:44', NULL, 1, 1, 1, 1, '2023-02-20 07:22:03', '2023-02-21 11:07:44'),
(10, 'Project Notification', 'You are assigned to a new project Sydney Bentley with deadline on 2023-03-20', 'project', '2023-02-20 16:55:37', 53, 1, 1, 1, NULL, '2023-02-20 11:10:37', '2023-02-20 11:10:37'),
(12, 'Support Notification', 'Your Support Request for asadasdsads 123 is viewed and is In_progress', 'support', '2023-02-21 10:23:48', 7, 1, 1, 1, NULL, '2023-02-21 04:38:48', '2023-02-21 04:38:48'),
(13, 'Task Assignment Notification', 'You are assigned to a new task this is test with deadline on 2023-02-22 10:34', 'task', '2023-02-21 10:35:17', 30, 1, 1, 1, NULL, '2023-02-21 04:50:17', '2023-02-21 04:50:17'),
(14, 'Comment Notification', 'You are mentioned in task create crud for TADA fetature comment', 'comment', '2023-02-21 11:51:32', 29, 1, 1, 1, NULL, '2023-02-21 06:06:32', '2023-02-21 06:06:32'),
(15, 'Leave Status Update', 'Your 1 day leave request requested on Jan 13 2023 11:53 AM has been  Rejected', 'leave', '2023-02-21 16:51:00', 3, 1, 1, 1, 1, '2023-02-21 06:17:10', '2023-02-21 11:06:00'),
(18, 'Project Notification', 'You are assigned to a new project nepali calender with deadline on 2023-3-11', 'project', '2023-03-09 11:36:04', 54, 1, 1, 1, NULL, '2023-03-09 05:51:04', '2023-03-09 05:51:04'),
(19, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 14:34:39', 30, 1, 1, 1, NULL, '2023-04-24 08:49:39', '2023-04-24 08:49:39'),
(20, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 15:14:22', 30, 1, 1, 1, NULL, '2023-04-24 09:29:22', '2023-04-24 09:29:22'),
(21, 'Comment Notification', 'You are mentioned in task this is test comment reply', 'comment', '2023-04-24 15:18:57', 30, 1, 1, 1, NULL, '2023-04-24 09:33:57', '2023-04-24 09:33:57'),
(22, 'Comment Notification', 'You are mentioned in task this is test comment reply', 'comment', '2023-04-24 15:19:04', 30, 1, 1, 1, NULL, '2023-04-24 09:34:04', '2023-04-24 09:34:04'),
(23, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 15:19:50', 30, 1, 1, 1, NULL, '2023-04-24 09:34:50', '2023-04-24 09:34:50'),
(24, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 15:20:00', 30, 1, 1, 1, NULL, '2023-04-24 09:35:00', '2023-04-24 09:35:00'),
(25, 'Comment Notification', 'You are mentioned in task this is test comment reply', 'comment', '2023-04-24 15:51:28', 30, 1, 1, 1, NULL, '2023-04-24 10:06:28', '2023-04-24 10:06:28'),
(26, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 16:20:26', 30, 1, 1, 1, NULL, '2023-04-24 10:35:26', '2023-04-24 10:35:26'),
(27, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 16:26:51', 30, 1, 1, 1, NULL, '2023-04-24 10:41:51', '2023-04-24 10:41:51'),
(28, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 16:28:24', 30, 1, 1, 1, NULL, '2023-04-24 10:43:24', '2023-04-24 10:43:24'),
(29, 'Comment Notification', 'You are mentioned in task this is test comment reply', 'comment', '2023-04-24 16:28:44', 30, 1, 1, 1, NULL, '2023-04-24 10:43:44', '2023-04-24 10:43:44'),
(30, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 16:51:30', 30, 1, 1, 1, NULL, '2023-04-24 11:06:30', '2023-04-24 11:06:30'),
(31, 'Comment Notification', 'You are mentioned in task this is test comment reply', 'comment', '2023-04-24 16:51:47', 30, 1, 1, 1, NULL, '2023-04-24 11:06:47', '2023-04-24 11:06:47'),
(32, 'Comment Notification', 'You are mentioned in task this is test comment', 'comment', '2023-04-24 17:04:25', 30, 1, 1, 4, NULL, '2023-04-24 11:19:25', '2023-04-24 11:19:25'),
(33, 'Project Notification', 'You are assigned to a new project Epic Event with deadline on 2080-02-26', 'project', '2023-05-05 15:47:52', 55, 1, 1, 1, NULL, '2023-05-05 10:02:52', '2023-05-05 10:02:52'),
(34, 'Project Notification', 'You are assigned to a new project Lorem ipsum with deadline on 2080-02-25', 'project', '2023-05-05 15:49:51', 56, 1, 1, 1, NULL, '2023-05-05 10:04:51', '2023-05-05 10:04:51'),
(35, 'Task Assignment Notification', 'You are assigned to a new task Lorem ipsum with deadline on 2023-05-26 15:51', 'task', '2023-05-05 15:51:41', 31, 1, 1, 1, NULL, '2023-05-05 10:06:41', '2023-05-05 10:06:41'),
(36, 'Comment Notification', 'You are mentioned in task Lorem ipsum comment', 'comment', '2023-05-05 15:52:42', 31, 1, 1, 1, NULL, '2023-05-05 10:07:42', '2023-05-05 10:07:42'),
(37, 'Support Notification', 'Your Support Request for this is what i have got is viewed and is In_progress', 'support', '2023-05-05 15:56:33', 21, 1, 1, 1, NULL, '2023-05-05 10:11:33', '2023-05-05 10:11:33'),
(38, 'Task Assignment Notification', 'You are assigned to a new task Epic Event with deadline on 2023-05-31 15:58', 'task', '2023-05-05 15:59:07', 32, 1, 1, 1, NULL, '2023-05-05 10:14:07', '2023-05-05 10:14:07'),
(39, 'Task Assignment Notification', 'You are assigned to a new task Helson Kell with deadline on 2023-06-21 16:42', 'task', '2023-05-05 16:43:12', 33, 1, 1, 1, NULL, '2023-05-05 10:58:12', '2023-05-05 10:58:12'),
(40, 'Task Assignment Notification', 'You are assigned to a new task farac afrstt with deadline on 2023-07-19 16:46', 'task', '2023-05-05 16:46:57', 34, 1, 1, 1, NULL, '2023-05-05 11:01:57', '2023-05-05 11:01:57'),
(41, 'Project Notification', 'You are assigned to a new project Not started projet with deadline on 2023-06-01', 'project', '2023-05-05 16:56:08', 57, 1, 1, 1, NULL, '2023-05-05 11:11:08', '2023-05-05 11:11:08'),
(42, 'Leave Status Update', 'Your 1 day leave request requested on Jan 13 2023 11:55 AM has been  Approved', 'leave', '2023-05-12 13:04:03', 2, 1, 1, 1, NULL, '2023-05-12 07:19:03', '2023-05-12 07:19:03'),
(43, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:45:48', 34, 1, 1, 1, NULL, '2023-05-12 10:00:48', '2023-05-12 10:00:48'),
(44, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:45:58', 34, 1, 1, 1, NULL, '2023-05-12 10:00:58', '2023-05-12 10:00:58'),
(45, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:46:52', 34, 1, 1, 1, NULL, '2023-05-12 10:01:52', '2023-05-12 10:01:52'),
(46, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:46:59', 34, 1, 1, 1, NULL, '2023-05-12 10:01:59', '2023-05-12 10:01:59'),
(47, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:48:25', 34, 1, 1, 1, NULL, '2023-05-12 10:03:25', '2023-05-12 10:03:25'),
(48, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:48:52', 34, 1, 1, 1, NULL, '2023-05-12 10:03:52', '2023-05-12 10:03:52'),
(49, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:49:51', 34, 1, 1, 1, NULL, '2023-05-12 10:04:51', '2023-05-12 10:04:51'),
(50, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 15:50:11', 34, 1, 1, 1, NULL, '2023-05-12 10:05:11', '2023-05-12 10:05:11'),
(51, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 16:23:30', 34, 1, 1, 1, NULL, '2023-05-12 10:38:30', '2023-05-12 10:38:30'),
(52, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 16:25:38', 34, 1, 1, 1, NULL, '2023-05-12 10:40:38', '2023-05-12 10:40:38'),
(53, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 16:25:57', 34, 1, 1, 1, NULL, '2023-05-12 10:40:57', '2023-05-12 10:40:57'),
(54, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 16:26:08', 34, 1, 1, 1, NULL, '2023-05-12 10:41:08', '2023-05-12 10:41:08'),
(55, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 16:26:34', 34, 1, 1, 1, NULL, '2023-05-12 10:41:34', '2023-05-12 10:41:34'),
(56, 'Comment Notification', 'You are mentioned in task farac afrstt comment', 'comment', '2023-05-12 16:29:13', 34, 1, 1, 1, NULL, '2023-05-12 10:44:13', '2023-05-12 10:44:13'),
(57, 'Project Notification', 'You are assigned to a new project asasdasdas with deadline on 2023-05-27', 'project', '2023-05-12 16:40:27', 58, 1, 1, 1, NULL, '2023-05-12 10:55:27', '2023-05-12 10:55:27'),
(58, 'Comment Notification', 'You are mentioned in task farac afrstt comment reply', 'comment', '2023-05-12 16:42:14', 34, 1, 1, 1, NULL, '2023-05-12 10:57:14', '2023-05-12 10:57:14'),
(59, 'Comment Notification', 'You are mentioned in task farac afrstt comment reply', 'comment', '2023-05-12 16:45:40', 34, 1, 1, 1, NULL, '2023-05-12 11:00:40', '2023-05-12 11:00:40'),
(60, 'Project Notification', 'You are assigned to a new project asasdasdas with deadline on 2023-05-27', 'project', '2023-05-12 16:45:51', 59, 1, 1, 1, NULL, '2023-05-12 11:00:51', '2023-05-12 11:00:51'),
(61, 'Comment Notification', 'You are mentioned in task farac afrstt comment reply', 'comment', '2023-05-12 16:47:05', 34, 1, 1, 1, NULL, '2023-05-12 11:02:05', '2023-05-12 11:02:05'),
(62, 'Comment Notification', 'You are mentioned in task farac afrstt comment reply', 'comment', '2023-05-12 16:49:40', 34, 1, 1, 1, NULL, '2023-05-12 11:04:40', '2023-05-12 11:04:40'),
(63, 'Task Assignment Notification', 'You are assigned to a new task Lucius Short with deadline on 2023-09-12 22:34', 'task', '2023-05-12 16:59:50', 35, 1, 1, 1, NULL, '2023-05-12 11:14:50', '2023-05-12 11:14:50');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('16ff2ce12a4db240371a19fdd2c83321fbe99a9a7ef1ecfdbeb0f2ca247cdc1e990fd4605378874c', 1, 1, 'MyToken1', '[]', 1, '2023-01-31 06:03:55', '2023-01-31 06:03:55', '2024-01-31 11:48:55'),
('264e94a443637df2a310567f0f128de0606ea0461031515f47c1dae23614394be8f9f22540db4b66', 3, 1, 'MyToken3', '[]', 1, '2023-01-31 06:05:48', '2023-01-31 06:05:48', '2024-01-31 11:50:48'),
('27eaa2cab479d49d761c55a48d970da718ace50240b034d46089150cde1624904d14e0e0f2bd9688', 4, 1, 'MyToken4', '[]', 1, '2023-02-09 04:46:39', '2023-02-09 04:46:39', '2024-02-09 10:31:39'),
('31efcdcc6dc3ca26f58b1289038030c420301d9cc4486adb4d43b151392aa8557fd5b529a6903c7e', 3, 1, 'MyToken3', '[]', 1, '2023-01-31 06:09:50', '2023-01-31 06:09:50', '2024-01-31 11:54:50'),
('387e0fe4d68c86287fe8b7d9492b9f68d7b2aa967a43dea8149a4ce0ece27b7e78be1a600c532500', 4, 1, 'MyToken4', '[]', 0, '2023-04-24 10:46:23', '2023-04-24 10:46:23', '2024-04-24 16:31:23'),
('3fa566ea8ea3c0603b79de54a9cb7a75bd1b8976ddbd2e0b9b834296092b234307e0ebaf406b038b', 4, 1, 'MyToken4', '[]', 1, '2023-01-30 07:12:12', '2023-01-30 07:12:12', '2024-01-30 12:57:12'),
('49644838fd07c50e14389e4c5e4c66f0c8b0908f77e64fcf1b656d56cc5d5cf9449884a7f7a4a076', 4, 1, 'MyToken4', '[]', 1, '2023-01-31 06:05:22', '2023-01-31 06:05:22', '2024-01-31 11:50:22'),
('564f6e0b6c017a569772c678e98b48c92bfe6e0b5caead87fca36d1d0eb9869a877aa1076dfd7ecf', 3, 1, 'MyToken3', '[]', 0, '2023-03-14 08:02:31', '2023-03-14 08:02:31', '2024-03-14 13:47:31'),
('59ff49c98dd91c5df7d6930a45fbe0536ff6cd563dfc284030c5afc8dc0980645f8fa7bbab3d68b1', 4, 1, 'MyToken4', '[]', 1, '2023-01-30 07:12:45', '2023-01-30 07:12:45', '2024-01-30 12:57:45'),
('8a5de2f9aeeb99ff5995079f11922fcc653db14767c9bfa6ec038df399601a9fcd1c349b55306603', 4, 1, 'MyToken4', '[]', 1, '2023-03-01 07:52:02', '2023-03-01 07:52:02', '2024-03-01 13:37:02'),
('ae2b9959da2cff110537f4567ed84e7a228a416f17c2d266eccfeb80737cedbf9e91722e15d85c2f', 4, 1, 'MyToken4', '[]', 1, '2023-02-03 09:40:31', '2023-02-03 09:40:31', '2024-02-03 15:25:31'),
('b18e7691158eed6124763d156e9c7761c6dba330030ef5952efdc52381edfadd7d0d4336eff3a5dd', 4, 1, 'MyToken4', '[]', 1, '2023-01-30 08:20:22', '2023-01-30 08:20:22', '2024-01-30 14:05:22'),
('b5e5ab84e2e45c88e7e259a63003d71ef6a8ab74f3ec5ae35d877806a8acccecaf35eee422577b43', 1, 1, 'MyToken1', '[]', 1, '2023-01-09 06:11:05', '2023-01-09 06:11:05', '2024-01-09 11:56:05'),
('b672375a7bdfda8bb8d40dc90f39f91ee04bb9381041fe1c611384cf854138076e4badab16e82b58', 4, 1, 'MyToken4', '[]', 1, '2023-01-13 05:38:10', '2023-01-13 05:38:10', '2024-01-13 11:23:10'),
('b7fed43d73a5ce1170341f928fefa3c91bb79cf5c65e566998657de2364545591f4856b8ee665bee', 1, 1, 'MyToken1', '[]', 1, '2023-02-02 08:33:46', '2023-02-02 08:33:46', '2024-02-02 14:18:46'),
('c1d83906448b5684e9c308ef180fa4220861427164f7e3d1eacd0cac9d1385561f2c8eab4ddf0780', 1, 1, 'MyToken1', '[]', 0, '2023-02-02 11:18:20', '2023-02-02 11:18:20', '2024-02-02 17:03:20'),
('e3fa5256718c8de0e40b8a76149c8e99ca0453c7002d4cad18bf02bdb43a29cad5e92932758aa77d', 3, 1, 'MyToken3', '[]', 1, '2023-02-08 10:53:32', '2023-02-08 10:53:32', '2024-02-08 16:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(191) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', '2S5yjVGLFkU1OKZ6sBiH7dVnBJTw6zvB3fhXq6ZP', NULL, 'http://localhost', 1, 0, 0, '2023-01-09 06:09:05', '2023-01-09 06:09:05'),
(2, NULL, 'Laravel Password Grant Client', 'MKS6dN7zOZ4e1HwQV4EKbkZj2Ni4rWLzkG7qh8d3', 'users', 'http://localhost', 0, 1, 0, '2023-01-09 06:09:05', '2023-01-09 06:09:05');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-01-09 06:09:05', '2023-01-09 06:09:05');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `office_times`
--

CREATE TABLE `office_times` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `opening_time` time NOT NULL,
  `closing_time` time NOT NULL,
  `shift` varchar(191) NOT NULL,
  `category` varchar(191) NOT NULL,
  `holiday_count` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `office_times`
--

INSERT INTO `office_times` (`id`, `opening_time`, `closing_time`, `shift`, `category`, `holiday_count`, `description`, `company_id`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, '10:00:00', '17:00:00', 'morning', 'full_timer', 12, '<p>Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Cras ultricies ligula sed magna dictum porta. Vivamus suscipit tortor eget felis porttitor volutpat. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus suscipit tortor eget felis porttitor volutpat. Cras ultricies ligula sed magna dictum porta.</p>', 1, 1, 1, 1, '2023-01-04 06:00:26', '2023-01-04 06:00:26'),
(2, '08:20:00', '17:41:00', 'morning', 'full_timer', 8, '<p>accumsan tincidunt. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.</p>', 1, 1, 1, 1, '2023-01-04 06:01:27', '2023-01-04 06:01:27');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('Ronish@mailinator.com', '$2y$10$2w1IRbyo6Z5dcHJhw.4NzejlWIB25cWb8hNZ1cTIozNgV5UQq/EE6', '2023-06-06 10:47:19'),
('admin@admin.com', '$2y$10$68IbTwBRdWKaosKaF4GkdOhOiZjTmQlHYBBIzeSi7xdKe446uwVHW', '2023-06-06 12:18:41');

-- --------------------------------------------------------

--
-- Table structure for table `payment_currencies`
--

CREATE TABLE `payment_currencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  `symbol` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_currencies`
--

INSERT INTO `payment_currencies` (`id`, `name`, `code`, `symbol`) VALUES
(6, 'Nepalese Rupee', 'NPR', '₨');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `slug`, `status`, `created_by`, `updated_by`) VALUES
(10, 'Cheque', 'cheque', 1, 1, 1),
(11, 'Paypal', 'paypal', 1, 1, 1),
(12, 'E-sewa', 'e-sewa', 1, 1, 1),
(13, 'Bank Transfer', 'bank-transfer', 1, 1, NULL),
(16, 'Cash', 'cash', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `permission_key` varchar(191) NOT NULL,
  `permission_groups_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `permission_key`, `permission_groups_id`) VALUES
(1, 'List Role', 'list_role', 1),
(2, 'Create Role', 'create_role', 1),
(3, 'Edit Role', 'edit_role', 1),
(4, 'Delete Role', 'delete_role', 1),
(5, 'List Permission', 'list_permission', 1),
(6, 'Assign Permission', 'assign_permission', 1),
(7, 'View Company', 'view_company', 2),
(8, 'Create Company', 'create_company', 2),
(9, 'Edit Company', 'edit_company', 2),
(10, 'List Branch', 'list_branch', 3),
(11, 'Create Branch', 'create_branch', 3),
(12, 'Edit Branch', 'edit_branch', 3),
(13, 'Delete Branch', 'delete_branch', 3),
(14, 'List Department', 'list_department', 4),
(15, 'Create Department', 'create_department', 4),
(16, 'Edit Department', 'edit_department', 4),
(17, 'Delete Department', 'delete_department', 4),
(18, 'List Post', 'list_post', 5),
(19, 'Create Post', 'create_post', 5),
(20, 'Edit Post', 'edit_post', 5),
(21, 'Delete Post', 'delete_post', 5),
(22, 'List Employee', 'list_employee', 6),
(23, 'Create Employee', 'create_employee', 6),
(24, 'Show Detail Employee', 'show_detail_employee', 6),
(25, 'Edit Employee', 'edit_employee', 6),
(26, 'Delete Employee', 'delete_employee', 6),
(27, 'Change Password', 'change_password', 6),
(28, 'Force Logout Employee', 'force_logout', 6),
(29, 'List Logout Request', 'list_logout_request', 6),
(30, 'Logout Request Accept', 'accept_logout_request', 6),
(31, 'List Router', 'list_router', 7),
(32, 'Create Router', 'create_router', 7),
(33, 'Edit Router', 'edit_router', 7),
(34, 'Delete Router', 'delete_router', 7),
(35, 'List General Setting', 'list_general_setting', 7),
(36, 'General Setting Update', 'general_setting_update', 7),
(37, 'List App Setting', 'list_app_setting', 7),
(38, 'Update App Setting', 'update_app_setting', 7),
(39, 'List Attendance', 'list_attendance', 8),
(40, 'Attendance CSV Export', 'attendance_csv_export', 8),
(41, 'Attendance Create', 'attendance_create', 8),
(42, 'Attendance Update', 'attendance_update', 8),
(43, 'Attendance Show', 'attendance_show', 8),
(44, 'Attendance Delete', 'attendance_delete', 8),
(45, 'List Leave Type', 'list_leave_type', 9),
(46, 'Leave Type Create', 'leave_type_create', 9),
(47, 'Leave Type Edit', 'leave_type_edit', 9),
(48, 'Leave Type Delete', 'leave_type_delete', 9),
(49, 'List Leave Requests', 'list_leave_request', 9),
(50, 'Show Leave Request Detail', 'show_leave_request_detail', 9),
(51, 'Update Leave request', 'update_leave_request', 9),
(52, 'List Holiday', 'list_holiday', 10),
(53, 'Holiday Create', 'create_holiday', 10),
(54, 'Show Detail', 'show_holiday', 10),
(55, 'Holiday Edit', 'edit_holiday', 10),
(56, 'Holiday Delete', 'delete_holiday', 10),
(57, 'Csv Import Holiday', 'import_holiday', 10),
(58, 'List Notice', 'list_notice', 11),
(59, 'Notice Create', 'create_notice', 11),
(60, 'Show Notice Detail', 'show_notice', 11),
(61, 'Notice Edit', 'edit_notice', 11),
(62, 'Notice Delete', 'delete_notice', 11),
(63, 'Send Notice', 'send_notice', 11),
(64, 'List Team Meeting', 'list_team_meeting', 12),
(65, 'Team Meeting Create', 'create_team_meeting', 12),
(66, 'Show Team Meeting Detail', 'show_team_meeting', 12),
(67, 'Team Meeting Edit', 'edit_team_meeting', 12),
(68, 'Team Meeting Delete', 'delete_team_meeting', 12),
(69, 'List Content', 'list_content', 13),
(70, 'Content Create', 'create_content', 13),
(71, 'Show Content Detail', 'show_content', 13),
(72, 'Content Edit', 'edit_content', 13),
(73, 'Content Delete', 'delete_content', 13),
(74, 'List Office Time', 'list_office_time', 14),
(75, 'Office Time Create', 'create_office_time', 14),
(76, 'Show Office Time Detail', 'show_office_time', 14),
(77, 'Office Time Edit', 'edit_office_time', 14),
(78, 'Office Time Delete', 'delete_office_time', 14),
(79, 'List Notification', 'list_notification', 15),
(80, 'Notification Create', 'create_notification', 15),
(81, 'Show Notification Detail', 'show_notification', 15),
(82, 'Notification Edit', 'edit_notification', 15),
(83, 'Notification Delete', 'delete_notification', 15),
(84, 'Send Notification', 'send_notification', 15),
(85, 'View Query List', 'view_query_list', 16),
(86, 'Show Query Detail', 'show_query_detail', 16),
(87, 'Update Status', 'update_query_status', 16),
(88, 'Delete Query', 'delete_query', 16),
(89, 'View Tada List', 'view_tada_list', 17),
(90, 'Create Tada ', 'create_tada', 17),
(91, 'Show Tada Detail', 'show_tada_detail', 17),
(92, 'Edit Tada', 'edit_tada', 17),
(93, 'Delete Tada', 'delete_tada', 17),
(94, 'Upload Attachment ', 'create_attachment', 17),
(95, 'Delete Attachment ', 'delete_attachment', 17),
(96, 'View Client List', 'view_client_list', 18),
(97, 'Create Client ', 'create_client', 18),
(98, 'Show Client Detail', 'show_client_detail', 18),
(99, 'Edit Client', 'edit_client', 18),
(100, 'Delete Client', 'delete_client', 18),
(101, 'View Project List', 'view_project_list', 19),
(102, 'Create Project', 'create_project', 19),
(103, 'Show Project Detail', 'show_project_detail', 19),
(104, 'Edit Project', 'edit_project', 19),
(105, 'Delete Project', 'delete_project', 19),
(106, 'Upload Project Attachment', 'upload_project_attachment', 19),
(107, 'Delete PM Attachment', 'delete_pm_attachment', 19),
(108, 'View Task List', 'view_task_list', 20),
(109, 'Create Task', 'create_task', 20),
(110, 'Show Task Detail', 'show_task_detail', 20),
(111, 'Edit Task', 'edit_task', 20),
(112, 'Delete Task', 'delete_task', 20),
(113, 'Upload Task Attachment', 'upload_task_attachment', 20),
(114, 'Create Checklist', 'create_checklist', 20),
(115, 'Edit Checklist', 'edit_checklist', 20),
(116, 'Delete Checklist', 'delete_checklist', 20),
(117, 'Create Comment', 'create_comment', 20),
(118, 'Delete Comment', 'delete_comment', 20),
(119, 'View Profile', 'view_profile', 21),
(120, 'Allow Password Change', 'allow_change_password', 21),
(121, 'Update Profile', 'update_profile', 21),
(122, 'Show Employee Detail', 'show_profile_detail', 21),
(123, 'Show Team Sheet', 'list_team_sheet', 21),
(124, 'Allow CheckIn', 'check_in', 22),
(125, 'Allow CheckOut', 'check_out', 22),
(126, 'Submit Leave Request', 'leave_request_create', 23),
(127, 'Submit Query', 'query_create', 24),
(128, 'Submit Tada Detail', 'tada_create', 25),
(129, 'Update Tada Detail', 'tada_update', 25),
(130, 'Delete Tada Attachment', 'delete_tada_attachment', 25),
(131, 'Change Task Status', 'edit_task_status', 26),
(132, 'Change Checklist Status', 'toggle_checklist_status', 26),
(133, 'Submit Comment', 'submit_comment', 26),
(134, 'Comment Delete', 'comment_delete', 26),
(135, 'Reply Delete', 'reply_delete', 26),
(136, 'Show Project Details', 'project_detail', 27),
(137, 'Show Client Details', 'client_detail', 27),
(138, 'Employee Attendance', 'allow_attendance', 27),
(139, 'List Asset Type', 'list_type', 28),
(140, 'Create Asset Type', 'create_type', 28),
(141, 'Show Type Detail', 'show_type', 28),
(142, 'Edit Asset Type', 'edit_type', 28),
(143, 'Delete Asset Type', 'delete_type', 28),
(144, 'List Assets', 'list_assets', 28),
(145, 'Create Assets Detail', 'create_assets', 28),
(146, 'Edit Assets Detail', 'edit_assets', 28),
(147, 'Show Assets Detail', 'show_asset', 28),
(148, 'Delete Assets Detail', 'delete_assets', 28);

-- --------------------------------------------------------

--
-- Table structure for table `permission_groups`
--

CREATE TABLE `permission_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `group_type_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_groups`
--

INSERT INTO `permission_groups` (`id`, `name`, `group_type_id`) VALUES
(1, 'Role', 1),
(2, 'Company', 1),
(3, 'Branch', 1),
(4, 'Department', 1),
(5, 'Post', 1),
(6, 'Employee', 1),
(7, 'Setting', 1),
(8, 'Attendance', 1),
(9, 'Leave', 1),
(10, 'Holiday', 1),
(11, 'Notice', 1),
(12, 'Team Meeting', 1),
(13, 'Content Management', 1),
(14, 'Shift Management', 1),
(15, 'Notification', 1),
(16, 'Support', 1),
(17, 'Tada', 1),
(18, 'Client', 1),
(19, 'Project Management', 1),
(20, 'Task Management', 1),
(21, 'Employee API', 2),
(22, 'Attendance API', 2),
(23, 'Leave API', 2),
(24, 'Support API', 2),
(25, 'Tada API', 2),
(26, 'Task Management API', 2),
(27, 'Dashboard', 1),
(28, 'Asset Management', 1);

-- --------------------------------------------------------

--
-- Table structure for table `permission_group_types`
--

CREATE TABLE `permission_group_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_group_types`
--

INSERT INTO `permission_group_types` (`id`, `name`, `slug`) VALUES
(1, 'Web', 'web'),
(2, 'API', 'api');

-- --------------------------------------------------------

--
-- Table structure for table `permission_roles`
--

CREATE TABLE `permission_roles` (
  `permission_id` bigint(20) UNSIGNED DEFAULT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_roles`
--

INSERT INTO `permission_roles` (`permission_id`, `role_id`) VALUES
(1, 2),
(7, 2),
(10, 2),
(11, 2),
(14, 2),
(16, 2),
(18, 2),
(22, 2),
(7, 4),
(10, 4),
(14, 4),
(52, 4),
(7, 3),
(15, 3),
(19, 3),
(23, 3),
(119, 3),
(120, 3),
(121, 3),
(122, 3),
(123, 3),
(124, 3),
(125, 3),
(126, 3),
(128, 3),
(129, 3),
(130, 3),
(131, 3),
(132, 3),
(133, 3),
(134, 3),
(135, 3),
(119, 4),
(120, 4),
(121, 4),
(122, 4),
(123, 4),
(124, 4),
(125, 4),
(126, 4),
(127, 4),
(128, 4),
(129, 4),
(130, 4),
(131, 4),
(132, 4),
(133, 4),
(134, 4),
(135, 4),
(137, 4),
(138, 3),
(137, 3),
(136, 3),
(127, 3),
(91, 3),
(89, 3),
(139, 3),
(143, 3),
(141, 3),
(146, 3);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_name` varchar(191) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `dept_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `post_name`, `is_active`, `dept_id`, `created_at`, `updated_at`) VALUES
(1, 'Senior Laravel Developer', 1, 1, '2023-01-04 05:59:26', '2023-01-04 05:59:26'),
(3, 'Senior wordpress developer', 1, 1, '2023-01-04 11:01:57', '2023-01-04 11:01:57'),
(4, 'Senior Frontend Developer', 1, 1, '2023-01-04 11:02:10', '2023-01-04 11:02:10'),
(5, 'Graphic Designer', 1, 1, '2023-01-04 11:02:23', '2023-01-04 11:02:23'),
(6, 'Junior Laravel Developer', 1, 1, '2023-01-04 11:02:35', '2023-01-04 11:02:35'),
(7, 'Marketing Chief', 1, 2, '2023-01-04 11:17:25', '2023-01-04 11:17:25'),
(8, 'Ceo', 1, 2, '2023-01-04 11:17:43', '2023-01-04 11:17:43');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `client_id` bigint(20) UNSIGNED DEFAULT NULL,
  `start_date` date NOT NULL,
  `deadline` date NOT NULL,
  `cost` double NOT NULL,
  `estimated_hours` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'not_started',
  `priority` varchar(191) NOT NULL DEFAULT 'low',
  `description` longtext NOT NULL,
  `cover_pic` varchar(191) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `client_id`, `start_date`, `deadline`, `cost`, `estimated_hours`, `status`, `priority`, `description`, `cover_pic`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(29, 'Ecommerce Site', 5, '2023-01-31', '2023-02-25', 123123, '12', 'cancelled', 'medium', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque neque est, iaculis eget mollis a, malesuada a turpis. Nam porta diam urna, id maximus ante faucibus eu. Duis luctus malesuada purus et tincidunt. Aliquam lacus mi, malesuada non mollis ut, hendrerit ac dolor. Fusce condimentum dui consectetur condimentum laoreet. Donec lobortis ligula eget ultrices tristique. Phasellus fringilla libero ac neque rutrum mattis. Donec viverra nulla sit amet nisl auctor rhoncus. Suspendisse pellentesque libero ac placerat volutpat. In non ex eget purus imperdiet sodales. Integer facilisis diam massa, quis suscipit nunc ullamcorper malesuada.</p>\r\n<ol>\r\n<li style=\"text-align: justify;\">In et ligula viverra, feugiat ante quis, cursus lacus. Donec eget vestibulum dolor. In vel ipsum sagittis, pellentesque orci sed, tempor elit. Aenean ut tortor non arcu sagittis ultricies ut bibendum nisl. Etiam ut est sed diam fermentum vulputate ut non est. Curabitur convallis vehicula tempus. Vivamus ac iaculis nunc. Ut sollicitudin at ligula non ultricies. In faucibus metus risus, et rutrum arcu consequat id. Nunc dignissim congue consequat. Aliquam erat volutpat. Donec mollis metus quis ipsum venenatis auctor. Nam id congue ligula. Nam sit amet scelerisque orci. Proin rhoncus, dui gravida aliquet ornare, risus metus rhoncus erat, interdum venenatis neque magna id mauris. Aliquam pharetra dui ut augue egestas rutrum.</li>\r\n</ol>', 'Thumb-63d8bd97ccf16_Screenshot_2022-11-10-13-34-32-97.jpg', 1, 1, 1, '2023-01-31 07:04:56', '2023-05-05 11:05:30'),
(34, 'testing main project health management', 6, '2023-02-01', '2023-04-01', 123, '1223', 'not_started', 'low', '<p>Sadasdadasd</p>', 'Thumb-63da089a45627_13 [Converted]-03.png', 1, 4, 1, '2023-02-01 06:37:14', '2023-05-05 11:43:18'),
(35, 'Attendance Application', 5, '2023-02-03', '2023-09-03', 69000, '27', 'completed', 'high', '<p>hgdgd</p>', 'Thumb-63dcd8bf5bca7_author.jpg', 1, 1, 1, '2023-02-03 09:49:51', '2023-02-03 11:34:15'),
(53, 'Sydney Bentley', 26, '2023-02-20', '2023-03-20', 49, '44', 'in_progress', 'medium', '<p>daewqe</p>', 'Thumb-63f3552d01644_Thumb-blog-20220721010104322.jpg', 1, 1, 1, '2023-02-20 11:10:37', '2023-05-05 10:12:42'),
(54, 'nepali calender', 21, '2023-03-09', '2023-03-12', 111, NULL, 'on_hold', 'low', '<p>this is test</p>', 'Thumb-640973c80e69e_photo_2022-04-17_13-52-38.jpg', 1, 1, 1, '2023-03-09 05:51:04', '2023-05-05 11:04:39'),
(56, 'Lorem ipsum', 25, '2023-01-09', '2023-02-12', 213223242423423, '432432', 'completed', 'high', '<p>Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum&nbsp;</p>', 'Thumb-6454d4c29a523_about-2-1.png', 1, 1, 1, '2023-05-05 10:04:50', '2023-05-05 11:24:02'),
(58, 'asasdasdas', 5, '2023-05-12', '2023-05-27', 123213, NULL, 'not_started', 'low', '<p>dasdasdasdasdsad</p>', 'Thumb-645e1b1f2cd4e_doctor-20221114110414339.jpg', 1, 1, 1, '2023-05-12 10:55:27', '2023-05-12 10:55:27'),
(59, 'asasdasdas', 5, '2023-05-12', '2023-05-27', 123213, NULL, 'not_started', 'low', '<p>dasdasdasdasdsad</p>', 'Thumb-645e1c62d3620_doctor-20221114110414339.jpg', 1, 1, 1, '2023-05-12 11:00:51', '2023-05-12 11:00:51');

-- --------------------------------------------------------

--
-- Table structure for table `project_team_leaders`
--

CREATE TABLE `project_team_leaders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `leader_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_team_leaders`
--

INSERT INTO `project_team_leaders` (`id`, `project_id`, `leader_id`) VALUES
(103, 35, 5),
(134, 53, 5),
(139, 54, 2),
(140, 29, 2),
(141, 29, 4),
(143, 56, 5),
(145, 34, 2),
(146, 58, 4),
(147, 59, 4);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `backend_login_authorize` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `is_active`, `backend_login_authorize`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin', 1, 1, NULL, 1, '2023-04-24 07:24:54', '2023-04-24 07:24:54'),
(2, 'manager', 'manager', 1, 0, 1, NULL, '2023-01-04 10:58:35', '2023-01-04 10:58:35'),
(3, 'assistent', 'assistent', 1, 1, 1, 1, '2023-01-04 10:59:12', '2023-04-25 07:58:54'),
(4, 'employee', 'employee', 1, 0, 1, NULL, '2023-01-04 10:59:19', '2023-01-04 10:59:19'),
(5, 'test', 'test', 1, 1, 1, NULL, '2023-04-25 08:03:36', '2023-04-25 08:03:36');

-- --------------------------------------------------------

--
-- Table structure for table `routers`
--

CREATE TABLE `routers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `router_ssid` varchar(191) NOT NULL,
  `branch_id` bigint(20) UNSIGNED NOT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `routers`
--

INSERT INTO `routers` (`id`, `router_ssid`, `branch_id`, `company_id`, `is_active`, `created_at`, `updated_at`) VALUES
(3, 'Facilis consequuntur', 1, 1, 1, '2023-01-11 12:04:28', '2023-01-11 12:04:28'),
(4, 'Quam reprehenderit', 2, 1, 1, '2023-01-11 12:04:38', '2023-01-11 12:04:38');

-- --------------------------------------------------------

--
-- Table structure for table `salary_components`
--

CREATE TABLE `salary_components` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `component_type` varchar(191) NOT NULL,
  `value_type` varchar(191) NOT NULL,
  `component_value_monthly` double NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salary_components`
--

INSERT INTO `salary_components` (`id`, `name`, `component_type`, `value_type`, `component_value_monthly`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Travel Allowance', 'earning', 'ctc', 5, 1, 1, 1, '2023-06-02 09:32:05', '2023-06-02 09:42:06'),
(3, 'Health Insurance', 'earning', 'fixed', 5000, 1, 1, 1, '2023-06-02 09:42:47', '2023-06-02 09:43:32'),
(4, 'Leave', 'deductions', 'fixed', 600, 1, 1, 1, '2023-06-02 09:56:38', '2023-06-02 09:57:03'),
(5, 'TDS', 'earning', 'ctc', 2, 1, 1, NULL, '2023-06-04 10:48:12', '2023-06-04 10:48:12'),
(8, 'SSF', 'earning', 'fixed', 4000, 1, 1, NULL, '2023-06-05 05:22:43', '2023-06-05 05:22:43');

-- --------------------------------------------------------

--
-- Table structure for table `salary_groups`
--

CREATE TABLE `salary_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salary_groups`
--

INSERT INTO `salary_groups` (`id`, `name`, `slug`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(3, 'Manager', 'manager', 1, 1, 1, '2023-06-07 06:53:16', '2023-06-07 07:04:50'),
(5, 'Employee', 'employee', 1, 1, NULL, '2023-06-07 07:14:05', '2023-06-07 07:14:05'),
(10, 'testing', 'testing', 1, 1, NULL, '2023-06-07 09:02:28', '2023-06-07 09:02:28');

-- --------------------------------------------------------

--
-- Table structure for table `salary_group_component`
--

CREATE TABLE `salary_group_component` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `salary_group_id` bigint(20) UNSIGNED NOT NULL,
  `salary_component_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salary_group_component`
--

INSERT INTO `salary_group_component` (`id`, `salary_group_id`, `salary_component_id`) VALUES
(4, 3, 1),
(5, 3, 3),
(7, 5, 4),
(8, 5, 5),
(14, 10, 3),
(15, 10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `salary_group_employees`
--

CREATE TABLE `salary_group_employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `salary_group_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salary_group_employees`
--

INSERT INTO `salary_group_employees` (`id`, `salary_group_id`, `employee_id`) VALUES
(9, 5, 2),
(10, 5, 3),
(11, 3, 3),
(12, 3, 6),
(13, 10, 2),
(14, 10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `salary_t_d_s`
--

CREATE TABLE `salary_t_d_s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `annual_salary_from` double NOT NULL,
  `annual_salary_to` double NOT NULL,
  `tds_in_percent` decimal(5,2) NOT NULL,
  `marital_status` varchar(191) NOT NULL DEFAULT 'single',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `salary_t_d_s`
--

INSERT INTO `salary_t_d_s` (`id`, `annual_salary_from`, `annual_salary_to`, `tds_in_percent`, `marital_status`, `status`, `created_by`, `updated_by`) VALUES
(1, 0, 500000, 1.00, 'married', 1, 1, 1),
(2, 400001, 1000000, 10.00, 'married', 1, 1, NULL),
(3, 0, 30000, 1.00, 'single', 1, 1, 1),
(4, 30001, 399999, 5.00, 'single', 1, 1, 1),
(6, 400000, 8000000, 15.00, 'single', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `supports`
--

CREATE TABLE `supports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'pending',
  `is_seen` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `supports`
--

INSERT INTO `supports` (`id`, `title`, `description`, `department_id`, `status`, `is_seen`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(6, 'help', 'Proin eget tortor risus.  elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'solved', 1, 4, 1, '2023-01-30 07:54:54', '2023-02-02 09:20:31'),
(7, 'asadasdsads 123', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 2, 'in_progress', 1, 4, 1, '2023-01-30 08:20:50', '2023-02-21 04:38:48'),
(10, 'help', 'Proin eget tortor risus.  elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'in_progress', 1, 4, 4, '2023-01-30 07:54:54', '2023-02-02 08:32:24'),
(11, 'asadasdsads 123', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'solved', 1, 4, 1, '2023-01-30 08:20:50', '2023-02-03 11:53:35'),
(12, 'help', 'Proin eget tortor risus.  elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'in_progress', 1, 4, 4, '2023-01-30 07:54:54', '2023-02-02 08:32:31'),
(13, 'asadasdsads 123', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'solved', 0, 4, 4, '2023-01-30 08:20:50', '2023-02-02 08:26:34'),
(14, 'help', 'Proin eget tortor risus.  elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'solved', 1, 4, 1, '2023-01-30 07:54:54', '2023-02-02 09:20:43'),
(15, 'asadasdsads 123', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 2, 'solved', 1, 4, 4, '2023-01-30 08:20:50', '2023-02-02 08:29:55'),
(16, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'in_progress', 1, 1, 1, '2023-02-02 08:34:00', '2023-02-21 04:37:11'),
(17, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'pending', 1, 4, 1, '2023-02-09 04:35:49', '2023-02-23 05:16:55'),
(18, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'pending', 0, 4, 4, '2023-05-04 05:43:59', '2023-05-04 05:43:59'),
(19, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'pending', 0, 4, 4, '2023-05-04 05:44:56', '2023-05-04 05:44:56'),
(20, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'pending', 1, 4, 1, '2023-05-04 05:44:58', '2023-05-12 07:19:53'),
(21, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 1, 'in_progress', 1, 4, 1, '2023-05-04 05:45:33', '2023-05-05 10:11:33'),
(22, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 2, 'pending', 1, 4, 1, '2023-05-04 05:46:29', '2023-05-05 10:11:18'),
(23, 'this is what i have got', 'Proin eget tortor risus. Pellentesque in ipsum id orci porta dapibus. Vivamus suscipit tortor eget felis porttitor volutpat. Sed porttitor lectus nibh. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Curabitur aliquet quam id dui posuere blandit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Proin eget tortor risus.', 2, 'pending', 0, 4, NULL, '2023-05-31 06:49:09', '2023-05-31 06:49:09');

-- --------------------------------------------------------

--
-- Table structure for table `tadas`
--

CREATE TABLE `tadas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` longtext DEFAULT NULL,
  `total_expense` double NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'pending',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `remark` varchar(191) DEFAULT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `verified_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tadas`
--

INSERT INTO `tadas` (`id`, `title`, `description`, `total_expense`, `status`, `is_active`, `remark`, `employee_id`, `verified_by`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(7, 'this is test update of tada', 'this is test update of tadathis is test update of tadathis is test update of tadathis is test update of tadathis is test update of tada', 99999, 'pending', 1, 'this is rejected because of the kjsnkjsf', 4, 1, 1, 4, '2023-02-07 07:49:54', '2023-06-04 05:57:58'),
(8, 'this is tada from api', 'yes yes we spent so much money on food pertol and accomodation while travelling to hetauda for bussiness meeting.we were 10 people on the tour.', 30000, 'pending', 1, NULL, 4, NULL, 4, 4, '2023-02-09 06:10:59', '2023-02-09 06:10:59'),
(9, 'this is tada from apiasdasdasdsada', '<p>yes yes we spent so much money on food pertol and accomodation while travelling to hetauda for bussiness meeting.we were 10 people on the tour.</p>', 30000, 'accepted', 1, NULL, 4, 1, 4, 1, '2023-02-09 06:42:10', '2023-05-04 07:18:00'),
(10, 'Recusandae Accusamu', '<p>xasadasdasd</p>', 60, 'pending', 1, NULL, 2, NULL, 1, 1, '2023-05-08 09:25:35', '2023-05-08 09:25:35'),
(11, 'Eu est vero voluptas', '<p>xaDASDASDASDASDSA ASDASD</p>', 61, 'pending', 1, NULL, 3, NULL, 1, 1, '2023-05-08 09:32:15', '2023-05-08 09:32:15'),
(12, 'Aut dolorum qui anim', '<p>addsa asasfasf csadsadd</p>', 47, 'rejected', 1, 'gffesreaewEWewaeeraeaew', 2, 1, 1, 1, '2023-05-08 09:33:19', '2023-05-11 05:50:17');

-- --------------------------------------------------------

--
-- Table structure for table `tada_attachments`
--

CREATE TABLE `tada_attachments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tada_id` bigint(20) UNSIGNED NOT NULL,
  `attachment` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tada_attachments`
--

INSERT INTO `tada_attachments` (`id`, `tada_id`, `attachment`, `created_at`, `updated_at`) VALUES
(42, 8, 'Thumb-63e48e731c4ad_photo_2022-04-17_13-52-38.jpg', '2023-02-09 06:10:59', '2023-02-09 06:10:59'),
(48, 9, 'Thumb-64535c2885530_Screenshot 2023-04-18 120313.png', '2023-05-04 07:18:00', '2023-05-04 07:18:00'),
(51, 9, 'Thumb-645362572df20_Screenshot 2023-05-01 174829.png', '2023-05-04 07:44:23', '2023-05-04 07:44:23'),
(59, 9, '645368aa8571c_sample.pdf', '2023-05-04 08:11:22', '2023-05-04 08:11:22'),
(60, 9, 'Thumb-645368b382269_Thumb-doctor-20221114111338364.jpg', '2023-05-04 08:11:31', '2023-05-04 08:11:31'),
(64, 10, '6458c00f1a6ae_sample.pdf', '2023-05-08 09:25:35', '2023-05-08 09:25:35'),
(65, 10, 'Thumb-6458c17cda525_doctor-20220728014211509.jpg', '2023-05-08 09:31:41', '2023-05-08 09:31:41'),
(66, 10, '6458c189ec209_sample.pdf', '2023-05-08 09:31:53', '2023-05-08 09:31:53'),
(67, 10, '6458c189ec603_sample2.pdf', '2023-05-08 09:31:53', '2023-05-08 09:31:53'),
(68, 11, 'Thumb-6458c19f9c9b9_doctor-20220728014211509.jpg', '2023-05-08 09:32:15', '2023-05-08 09:32:15'),
(69, 11, 'Thumb-6458c19fb919d_goticket.jpg', '2023-05-08 09:32:15', '2023-05-08 09:32:15'),
(70, 12, 'Thumb-6458c1df31479_doctor-20221114110414339.jpg', '2023-05-08 09:33:19', '2023-05-08 09:33:19'),
(71, 12, 'Thumb-6458c1df4d2ad_goticket.jpg', '2023-05-08 09:33:19', '2023-05-08 09:33:19'),
(74, 7, 'Thumb-6458c6a4d4752_doctor-20220728014211509.jpg', '2023-05-08 09:53:40', '2023-05-08 09:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `priority` varchar(191) NOT NULL DEFAULT 'low',
  `status` varchar(191) NOT NULL DEFAULT 'not_started',
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `name`, `priority`, `status`, `start_date`, `end_date`, `description`, `is_active`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(19, 29, 'Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta.', 'urgent', 'in_progress', '2023-02-15 12:56:00', '2023-02-16 12:56:00', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque neque est, iaculis eget mollis a, malesuada a turpis. Nam porta diam urna, id maximus ante faucibus eu. Duis luctus malesuada purus et tincidunt. Aliquam lacus mi, malesuada non mollis ut, hendrerit ac dolor. Fusce condimentum dui consectetur condimentum laoreet. Donec lobortis ligula eget ultrices tristique. Phasellus fringilla libero ac neque rutrum mattis. Donec viverra nulla sit amet nisl auctor rhoncus. Suspendisse pellentesque libero ac placerat volutpat. In non ex eget purus imperdiet sodales. Integer facilisis diam massa, quis suscipit nunc ullamcorper malesuada.</p>\r\n<p>In et ligula viverra, feugiat ante quis, cursus lacus. Donec eget vestibulum dolor. In vel ipsum sagittis, pellentesque orci sed, tempor elit. Aenean ut tortor non arcu sagittis ultricies ut bibendum nisl. Etiam ut est sed diam fermentum vulputate ut non est. Curabitur convallis vehicula tempus. Vivamus ac iaculis nunc. Ut sollicitudin at ligula non ultricies. In faucibus metus risus, et rutrum arcu consequat id. Nunc dignissim congue consequat. Aliquam erat volutpat. Donec mollis metus quis ipsum venenatis auctor. Nam id congue ligula. Nam sit amet scelerisque orci. Proin rhoncus, dui gravida aliquet ornare, risus metus rhoncus erat, interdum venenatis neque magna id mauris. Aliquam pharetra dui ut augue egestas rutrum.</p>', 1, 1, 4, '2023-01-31 07:13:04', '2023-02-02 10:29:41'),
(20, 29, 'test 1', 'high', 'in_progress', '2023-02-02 16:13:00', '2023-02-03 16:13:00', '<p>adsadasd</p>', 1, 4, 4, '2023-02-02 10:29:22', '2023-02-02 10:37:47'),
(21, 34, 'Nyssa Battle', 'high', 'cancelled', '2023-02-02 16:11:00', '2023-02-04 00:14:00', '<p>sADSDS</p>', 1, 4, 1, '2023-02-02 10:32:52', '2023-05-05 10:10:53'),
(22, 29, 'Xandra West', 'urgent', 'completed', '2023-02-02 21:01:00', '2023-02-06 10:39:00', '<p>ASDAS</p>', 1, 4, 1, '2023-02-02 10:34:30', '2023-02-08 10:55:07'),
(27, 34, 'Yoshio Mason', 'urgent', 'in_progress', '2023-02-03 02:27:00', '2023-02-17 10:27:00', '<p>xxasasdasd</p>', 1, 4, 4, '2023-02-03 05:55:47', '2023-02-03 06:01:56'),
(28, 34, 'Brenna Moreno', 'medium', 'completed', '2023-02-03 00:13:00', '2023-02-10 19:11:00', '<p>xsaasdsadasd</p>', 1, 4, 1, '2023-02-03 06:02:24', '2023-05-05 10:11:18'),
(29, 35, 'create crud for TADA fetature', 'medium', 'completed', '2023-02-03 09:02:00', '2023-02-05 23:05:00', '<p>this is test only</p>', 1, 1, 1, '2023-02-03 09:56:56', '2023-02-03 11:31:09'),
(30, 53, 'this is test', 'medium', 'in_progress', '2023-02-21 10:34:00', '2023-02-22 10:34:00', '<p>sadasdsadsa</p>', 1, 1, 1, '2023-02-21 04:50:17', '2023-05-05 10:12:42'),
(33, 54, 'Helson Kell', 'medium', 'in_progress', '2023-05-27 16:42:00', '2023-06-21 16:42:00', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 1, 1, '2023-05-05 10:58:11', '2023-05-05 10:58:31'),
(34, 56, 'farac afrstt', 'urgent', 'completed', '2023-05-25 16:46:00', '2023-07-19 16:46:00', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 1, 1, '2023-05-05 11:01:56', '2023-05-05 11:07:15'),
(35, 53, 'Lucius Short', 'low', 'on_hold', '2023-05-12 23:38:00', '2023-09-12 22:34:00', '<p>aSDASDSADDSA</p>', 1, 1, 1, '2023-05-12 11:14:50', '2023-05-12 11:14:50');

-- --------------------------------------------------------

--
-- Table structure for table `task_checklists`
--

CREATE TABLE `task_checklists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `assigned_to` bigint(20) UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `is_completed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `task_checklists`
--

INSERT INTO `task_checklists` (`id`, `task_id`, `assigned_to`, `name`, `is_completed`) VALUES
(92, 19, 2, 'Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta.', 1),
(93, 19, 3, 'Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Nulla quis lorem ut libero malesuada feugiat. Donec rutrum congue leo eget malesuada', 0),
(94, 20, 2, 'Lucius Meadows', 1),
(95, 20, 3, 'dasdsad', 0),
(96, 22, 3, 'This is test route test', 1),
(97, 28, 4, 'this is checklist', 1),
(98, 28, 4, 'LOREM IPSUM GENERATOR Lorem ipsum dolor sit amet, consectetur adipiscing elit', 1),
(99, 28, 5, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', 1),
(100, 28, 4, 'LOREM IPSUM GENERATOR Lorem ipsum dolor sit amet, consectetur adipiscing elit', 1),
(101, 28, 5, 'LOREM IPSUM GENERATOR Lorem ipsum dolor sit amet, consectetur adipiscing elit', 1),
(102, 28, 4, 'LOREM IPSUM GENERATOR Lorem ipsum dolor sit amet, consectetur adipiscing elit', 1),
(104, 29, 2, 'this is done', 1),
(105, 29, 2, 'ok fine', 1),
(106, 29, 2, 'whoe is he', 1),
(107, 22, 3, '3', 1),
(111, 30, 2, 'Excepteur sint occaecat cupidatat non', 1),
(112, 30, 4, 'Please to do database work within a week', 0),
(113, 30, 2, 'Duis aute irure dolor in reprehenderit', 1),
(116, 33, 2, 'Please to do database work within a week', 1),
(117, 33, 3, 'Need to follow all the pattern of health', 0),
(118, 34, 4, 'Excepteur sint occaecat cupidatat non', 1),
(119, 34, 4, 'Need to follow all the pattern of health', 1),
(120, 34, 4, 'Excepteur sint occaecat cupidatat non', 1);

-- --------------------------------------------------------

--
-- Table structure for table `task_comments`
--

CREATE TABLE `task_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `description` text NOT NULL,
  `task_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `task_comments`
--

INSERT INTO `task_comments` (`id`, `description`, `task_id`, `created_by`, `created_at`, `updated_at`) VALUES
(23, 'hello', 19, 1, '2023-02-01 11:05:04', '2023-02-01 11:05:04'),
(24, 'asdasff', 28, 1, '2023-02-17 07:01:31', '2023-02-17 07:01:31'),
(25, 'this is test comment', 29, 1, '2023-02-21 06:06:32', '2023-02-21 06:06:32'),
(26, 'fdsfdsfdsf', 30, 1, '2023-03-09 04:48:00', '2023-03-09 04:48:00'),
(27, 'weqweqwewqe', 30, 1, '2023-04-24 08:20:23', '2023-04-24 08:20:23'),
(49, 'sadsafdf', 30, 1, '2023-04-24 10:43:24', '2023-04-24 10:43:24'),
(50, 'oky let it be mine asdsadasdsad', 30, 4, '2023-04-24 10:50:20', '2023-04-24 10:50:20'),
(51, 'oky let it be mine asdsadasdsad', 30, 4, '2023-04-24 10:53:29', '2023-04-24 10:53:29'),
(52, 'dsafdfdsf', 30, 1, '2023-04-24 11:06:30', '2023-04-24 11:06:30'),
(65, 'sadasdasdasdsad', 30, 4, '2023-04-24 11:19:25', '2023-04-24 11:19:25'),
(66, 'dsadasdasd', 30, 4, '2023-04-24 11:19:48', '2023-04-24 11:19:48'),
(67, 'dsadasdasd', 30, 4, '2023-04-24 11:19:55', '2023-04-24 11:19:55'),
(68, 'fghghghj', 29, 1, '2023-04-28 11:48:26', '2023-04-28 11:48:26'),
(69, 'dasffdf', 29, 1, '2023-04-28 11:48:31', '2023-04-28 11:48:31'),
(70, 'ghgfhfg', 29, 1, '2023-04-28 11:48:35', '2023-04-28 11:48:35'),
(72, 'oky let it be mine asdsadasdsad', 30, 4, '2023-05-12 07:32:11', '2023-05-12 07:32:11'),
(73, 'oky let it be mine asdsadasdsad', 30, 4, '2023-05-12 07:32:25', '2023-05-12 07:32:25'),
(74, 'dasdasdasdasdasd', 34, 1, '2023-05-12 10:00:48', '2023-05-12 10:00:48'),
(83, 'asdffdsf', 34, 1, '2023-05-12 10:36:01', '2023-05-12 10:36:01'),
(88, 'asdffdsf', 34, 1, '2023-05-12 10:41:34', '2023-05-12 10:41:34');

-- --------------------------------------------------------

--
-- Table structure for table `team_meetings`
--

CREATE TABLE `team_meetings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` longtext NOT NULL,
  `venue` varchar(191) NOT NULL,
  `meeting_date` date NOT NULL,
  `meeting_start_time` time NOT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `image` text DEFAULT NULL,
  `meeting_published_at` datetime NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_meetings`
--

INSERT INTO `team_meetings` (`id`, `title`, `description`, `venue`, `meeting_date`, `meeting_start_time`, `company_id`, `image`, `meeting_published_at`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Consectetur et est i', 'Voluptas duis aut co', 'Sit modi ab dicta te', '2023-04-03', '01:06:00', 1, 'Thumb-64017e0ff287b_photo_2022-04-17_13-52-38.jpg', '2023-03-03 11:49:59', 1, 1, '2023-03-03 04:56:48', '2023-03-03 06:04:59'),
(2, 'Delectus nulla mole', 'Aut et eos commodo u', 'Et aut laudantium f', '2023-03-04', '21:10:00', 1, 'Thumb-6401885c2dbab_photo_2022-04-17_13-52-38.jpg', '2023-03-03 11:50:48', 1, 1, '2023-03-03 05:40:44', '2023-03-03 06:05:48');

-- --------------------------------------------------------

--
-- Table structure for table `team_meeting_members`
--

CREATE TABLE `team_meeting_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_meeting_id` bigint(20) UNSIGNED NOT NULL,
  `meeting_participator_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_meeting_members`
--

INSERT INTO `team_meeting_members` (`id`, `team_meeting_id`, `meeting_participator_id`) VALUES
(4, 1, 3),
(5, 1, 4),
(6, 1, 5),
(7, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `username` varchar(191) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `address` varchar(191) DEFAULT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(191) NOT NULL DEFAULT 'male',
  `phone` double DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'verified',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `online_status` tinyint(1) NOT NULL DEFAULT 0,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `leave_allocated` int(11) DEFAULT NULL,
  `employment_type` varchar(191) NOT NULL DEFAULT 'temporary',
  `user_type` varchar(191) NOT NULL DEFAULT 'field',
  `joining_date` date DEFAULT NULL,
  `workspace_type` tinyint(1) NOT NULL DEFAULT 1,
  `uuid` text DEFAULT NULL,
  `fcm_token` longtext DEFAULT NULL,
  `device_type` varchar(191) DEFAULT NULL,
  `logout_status` tinyint(1) NOT NULL DEFAULT 0,
  `remarks` longtext DEFAULT NULL,
  `company_id` bigint(20) UNSIGNED DEFAULT NULL,
  `branch_id` bigint(20) UNSIGNED DEFAULT NULL,
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `supervisor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `office_time_id` bigint(20) UNSIGNED DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `marital_status` varchar(191) NOT NULL DEFAULT 'single'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `email_verified_at`, `password`, `address`, `avatar`, `dob`, `gender`, `phone`, `status`, `is_active`, `online_status`, `role_id`, `leave_allocated`, `employment_type`, `user_type`, `joining_date`, `workspace_type`, `uuid`, `fcm_token`, `device_type`, `logout_status`, `remarks`, `company_id`, `branch_id`, `department_id`, `post_id`, `supervisor_id`, `office_time_id`, `remember_token`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`, `marital_status`) VALUES
(1, 'Santosh Maharjan', 'admin@admin.com', 'admin123', NULL, '$2y$10$Rc.KfzNB/xnRifU930weouKEwrbGgVun80TJ3wuo6Qa7rEdlY09jO', 'kathmandu,Nepal', 'Thumb-63d7a63cc548e_author.jpg', '2023-01-19', 'male', 9811111111, 'verified', 1, 0, 1, 12, 'contract', 'field', '2023-01-26', 1, 'asdadasfasfasfasf', 'hzgxsahgchgsa', 'ios', 0, '<p>dasdasdasdsa</p>', 1, 1, 1, 2, 1, 1, NULL, NULL, 1, NULL, '2022-12-29 11:05:43', '2023-06-08 11:17:53', NULL, 'single'),
(2, 'Sandeep Pant', 'sandeep@gmail.com', 'sandeep23', NULL, '$2y$10$.jgMhlmZ3Wn40SCH4GF/BeoQnq6rcfnciSahmLYaLdyUeoQd9N1dS', 'kathamandu', 'Thumb-63b55bcc74e79_blog2.jpg', '2023-01-02', 'male', 9812604223, 'verified', 1, 0, 2, 12, 'permanent', 'nonField', '2023-01-04', 0, NULL, NULL, 'ios', 0, '<p>Cras ultricies ligula sed magna dictum porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel,&nbsp;</p>', 1, 1, 1, 1, 1, 1, NULL, 1, 1, NULL, '2023-01-04 10:58:20', '2023-06-08 11:35:22', NULL, 'single'),
(3, 'Brishav', 'Brishav@Brishav.com', 'Brishav', NULL, '$2y$10$SsFuaKdmio55cMa7gelia.jfIshNx83hhrLPGMGdV7eb3u6jwFHb6', 'Rerum voluptas exped', 'Thumb-63b55c69f4196_calltoaction.jpg', '1985-07-15', 'male', 9812604111, 'verified', 1, 1, 2, 7, 'contract', 'field', '2023-01-04', 0, 'asdadasfasfasfasf', NULL, 'ios', 0, '<p>Proin eget tortor risus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Pellentesque in ipsum id orci porta dapibus. Proin eget tortor risus. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Proin eget tortor risus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Nulla porttitor accumsan tincidunt. Donec sollicitudin molestie malesuada.</p>', 1, 1, 1, 1, 2, 2, NULL, 1, 1, NULL, '2023-01-04 11:00:58', '2023-05-11 11:06:23', NULL, 'single'),
(4, 'Ronish', 'Ronish@mailinator.com', 'ronish123', NULL, '$2y$10$uh57vuIEgpCP2hndXmD7juo66AmqduTk.k06c8y40kKs/Lw9PvPuW', 'Quod aute ut dolorem', 'Thumb-63b55fcfda962_meet.png', '1972-04-17', 'male', 987777777, 'verified', 1, 1, 3, 13, 'permanent', 'nonField', '2023-01-01', 0, 'asdadasfasfasfasf', 'hzgxsahgchgsa', 'android', 0, '<p>Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla quis lorem ut libero malesuada feugiat. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Nulla porttitor accumsan tincidunt. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus. Curabitur aliquet quam id dui posuere blandit. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.</p>', 1, 1, 1, 1, 1, 1, NULL, 1, 1, NULL, '2023-01-04 11:15:28', '2023-05-12 05:38:19', NULL, 'single'),
(5, 'Samin Tha', 'Samin@mailinator.com', 'samim', NULL, '$2y$10$r.LSXtxmdJjbJXfGmdeqgego.suZwkNGwmZkB4Tm62Zo3O5Urfq9m', 'Mollitia a laboriosa', 'Thumb-647864f334e94_doctor-20220728014211509.jpg', '2013-05-26', 'male', 980000000000, 'verified', 1, 1, 2, NULL, 'permanent', 'nonField', '1971-10-17', 0, NULL, NULL, 'android', 0, '<p>Vivamus suscipit tortor eget felis porttitor volutpat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Curabitur non nulla sit amet nisl tempus&nbsp;</p>', 1, 1, 1, 4, 1, 1, NULL, 1, 1, NULL, '2023-01-04 11:17:03', '2023-06-01 09:29:23', NULL, 'single'),
(6, 'Test User', 'bufidi@mailinator.com', 'test123', NULL, '$2y$10$0Dm1ZhyUFcobu6J3qVmuTuf582derT3MWd2m1H8Rq9i6q1sgOOw1K', 'Inventore natus aut', 'Thumb-64785a7ac1020_doctor-20220728014211509.jpg', '2005-05-03', 'female', 9898080808, 'verified', 1, 0, 4, 47, 'contract', 'nonField', '1985-10-20', 0, NULL, NULL, NULL, 0, '<p>xsaczxczxczxc&nbsp;</p>', 1, 1, 1, 1, 2, 2, NULL, 1, 1, NULL, '2023-06-01 08:44:42', '2023-06-01 09:03:21', NULL, 'single');

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `is_seen` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_notifications`
--

INSERT INTO `user_notifications` (`id`, `notification_id`, `user_id`, `is_seen`, `created_at`, `updated_at`) VALUES
(13, 10, 2, 0, '2023-02-20 11:10:37', '2023-02-20 11:10:37'),
(14, 10, 4, 0, '2023-02-20 11:10:37', '2023-02-20 11:10:37'),
(15, 10, 5, 0, '2023-02-20 11:10:37', '2023-02-20 11:10:37'),
(16, 12, 4, 1, '2023-02-21 04:38:48', '2023-02-21 04:38:48'),
(17, 13, 2, 0, '2023-02-21 04:50:17', '2023-02-21 04:50:17'),
(18, 13, 4, 0, '2023-02-21 04:50:17', '2023-02-21 04:50:17'),
(19, 14, 2, 0, '2023-02-21 06:06:32', '2023-02-21 06:06:32'),
(20, 15, 4, 0, '2023-02-21 06:17:10', '2023-02-21 06:17:10'),
(23, 18, 2, 0, '2023-03-09 05:51:04', '2023-03-09 05:51:04'),
(24, 18, 3, 0, '2023-03-09 05:51:04', '2023-03-09 05:51:04'),
(25, 19, 4, 0, '2023-04-24 08:49:39', '2023-04-24 08:49:39'),
(26, 20, 4, 0, '2023-04-24 09:29:22', '2023-04-24 09:29:22'),
(27, 21, 2, 0, '2023-04-24 09:33:57', '2023-04-24 09:33:57'),
(28, 21, 1, 0, '2023-04-24 09:33:57', '2023-04-24 09:33:57'),
(29, 22, 2, 0, '2023-04-24 09:34:04', '2023-04-24 09:34:04'),
(30, 22, 1, 0, '2023-04-24 09:34:04', '2023-04-24 09:34:04'),
(31, 23, 4, 0, '2023-04-24 09:34:50', '2023-04-24 09:34:50'),
(32, 23, 1, 0, '2023-04-24 09:34:50', '2023-04-24 09:34:50'),
(33, 24, 1, 0, '2023-04-24 09:35:00', '2023-04-24 09:35:00'),
(34, 25, 2, 0, '2023-04-24 10:06:28', '2023-04-24 10:06:28'),
(35, 25, 4, 0, '2023-04-24 10:06:28', '2023-04-24 10:06:28'),
(36, 25, 1, 0, '2023-04-24 10:06:28', '2023-04-24 10:06:28'),
(37, 26, 2, 0, '2023-04-24 10:35:26', '2023-04-24 10:35:26'),
(38, 26, 4, 0, '2023-04-24 10:35:26', '2023-04-24 10:35:26'),
(39, 26, 1, 0, '2023-04-24 10:35:26', '2023-04-24 10:35:26'),
(40, 27, 2, 0, '2023-04-24 10:41:51', '2023-04-24 10:41:51'),
(41, 27, 4, 0, '2023-04-24 10:41:51', '2023-04-24 10:41:51'),
(42, 27, 1, 0, '2023-04-24 10:41:51', '2023-04-24 10:41:51'),
(43, 28, 2, 0, '2023-04-24 10:43:24', '2023-04-24 10:43:24'),
(44, 28, 4, 0, '2023-04-24 10:43:24', '2023-04-24 10:43:24'),
(45, 28, 1, 0, '2023-04-24 10:43:24', '2023-04-24 10:43:24'),
(46, 29, 4, 0, '2023-04-24 10:43:44', '2023-04-24 10:43:44'),
(47, 29, 1, 0, '2023-04-24 10:43:44', '2023-04-24 10:43:44'),
(48, 30, 1, 0, '2023-04-24 11:06:30', '2023-04-24 11:06:30'),
(49, 31, 4, 0, '2023-04-24 11:06:47', '2023-04-24 11:06:47'),
(50, 31, 1, 0, '2023-04-24 11:06:47', '2023-04-24 11:06:47'),
(51, 32, 1, 0, '2023-04-24 11:19:25', '2023-04-24 11:19:25'),
(52, 33, 3, 0, '2023-05-05 10:02:52', '2023-05-05 10:02:52'),
(53, 33, 2, 0, '2023-05-05 10:02:52', '2023-05-05 10:02:52'),
(54, 34, 4, 0, '2023-05-05 10:04:51', '2023-05-05 10:04:51'),
(55, 34, 5, 0, '2023-05-05 10:04:51', '2023-05-05 10:04:51'),
(56, 35, 3, 0, '2023-05-05 10:06:41', '2023-05-05 10:06:41'),
(57, 36, 3, 0, '2023-05-05 10:07:42', '2023-05-05 10:07:42'),
(58, 37, 4, 0, '2023-05-05 10:11:33', '2023-05-05 10:11:33'),
(59, 38, 3, 0, '2023-05-05 10:14:07', '2023-05-05 10:14:07'),
(60, 39, 2, 0, '2023-05-05 10:58:12', '2023-05-05 10:58:12'),
(61, 39, 3, 0, '2023-05-05 10:58:12', '2023-05-05 10:58:12'),
(62, 40, 4, 0, '2023-05-05 11:01:57', '2023-05-05 11:01:57'),
(63, 41, 2, 0, '2023-05-05 11:11:08', '2023-05-05 11:11:08'),
(64, 41, 3, 0, '2023-05-05 11:11:08', '2023-05-05 11:11:08'),
(65, 42, 4, 0, '2023-05-12 07:19:03', '2023-05-12 07:19:03'),
(66, 43, 4, 0, '2023-05-12 10:00:48', '2023-05-12 10:00:48'),
(67, 44, 4, 0, '2023-05-12 10:00:58', '2023-05-12 10:00:58'),
(68, 45, 4, 0, '2023-05-12 10:01:52', '2023-05-12 10:01:52'),
(69, 46, 4, 0, '2023-05-12 10:01:59', '2023-05-12 10:01:59'),
(70, 47, 4, 0, '2023-05-12 10:03:25', '2023-05-12 10:03:25'),
(71, 48, 4, 0, '2023-05-12 10:03:52', '2023-05-12 10:03:52'),
(72, 49, 4, 0, '2023-05-12 10:04:51', '2023-05-12 10:04:51'),
(73, 50, 4, 0, '2023-05-12 10:05:11', '2023-05-12 10:05:11'),
(74, 51, 4, 0, '2023-05-12 10:38:30', '2023-05-12 10:38:30'),
(75, 52, 4, 0, '2023-05-12 10:40:38', '2023-05-12 10:40:38'),
(76, 53, 4, 0, '2023-05-12 10:40:57', '2023-05-12 10:40:57'),
(77, 54, 4, 0, '2023-05-12 10:41:08', '2023-05-12 10:41:08'),
(78, 55, 4, 0, '2023-05-12 10:41:34', '2023-05-12 10:41:34'),
(79, 56, 4, 0, '2023-05-12 10:44:13', '2023-05-12 10:44:13'),
(80, 57, 4, 0, '2023-05-12 10:55:27', '2023-05-12 10:55:27'),
(81, 58, 4, 0, '2023-05-12 10:57:14', '2023-05-12 10:57:14'),
(82, 59, 4, 0, '2023-05-12 11:00:40', '2023-05-12 11:00:40'),
(83, 60, 4, 0, '2023-05-12 11:00:51', '2023-05-12 11:00:51'),
(84, 61, 4, 0, '2023-05-12 11:02:05', '2023-05-12 11:02:05'),
(85, 62, 4, 0, '2023-05-12 11:04:40', '2023-05-12 11:04:40'),
(86, 63, 2, 0, '2023-05-12 11:14:50', '2023-05-12 11:14:50'),
(87, 63, 4, 0, '2023-05-12 11:14:50', '2023-05-12 11:14:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_settings`
--
ALTER TABLE `app_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `app_settings_slug_unique` (`slug`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assets_type_id_foreign` (`type_id`),
  ADD KEY `assets_assigned_to_foreign` (`assigned_to`),
  ADD KEY `assets_created_by_foreign` (`created_by`),
  ADD KEY `assets_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `asset_types`
--
ALTER TABLE `asset_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_types_created_by_foreign` (`created_by`),
  ADD KEY `asset_types_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `assigned_members`
--
ALTER TABLE `assigned_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assigned_members_assignable_type_assignable_id_index` (`assignable_type`,`assignable_id`),
  ADD KEY `assigned_members_member_id_foreign` (`member_id`);

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attachments_attachable_type_attachable_id_index` (`attachable_type`,`attachable_id`);

--
-- Indexes for table `attendances`
--
ALTER TABLE `attendances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attendances_user_id_foreign` (`user_id`),
  ADD KEY `attendances_created_by_foreign` (`created_by`),
  ADD KEY `attendances_company_id_foreign` (`company_id`),
  ADD KEY `attendances_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branches_branch_head_id_foreign` (`branch_head_id`),
  ADD KEY `branches_company_id_foreign` (`company_id`),
  ADD KEY `branches_created_by_foreign` (`created_by`),
  ADD KEY `branches_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clients_created_by_foreign` (`created_by`),
  ADD KEY `clients_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `comment_replies`
--
ALTER TABLE `comment_replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comment_replies_comment_id_foreign` (`comment_id`),
  ADD KEY `comment_replies_created_by_foreign` (`created_by`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `companies_email_unique` (`email`),
  ADD KEY `companies_created_by_foreign` (`created_by`),
  ADD KEY `companies_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `company_content_management`
--
ALTER TABLE `company_content_management`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_content_management_created_by_foreign` (`created_by`),
  ADD KEY `company_content_management_updated_by_foreign` (`updated_by`),
  ADD KEY `company_content_management_company_id_foreign` (`company_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `departments_dept_head_id_foreign` (`dept_head_id`),
  ADD KEY `departments_company_id_foreign` (`company_id`),
  ADD KEY `departments_branch_id_foreign` (`branch_id`),
  ADD KEY `departments_created_by_foreign` (`created_by`),
  ADD KEY `departments_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `employee_accounts`
--
ALTER TABLE `employee_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_accounts_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
  ADD PRIMARY KEY (`id`),
  ADD KEY `holidays_company_id_foreign` (`company_id`),
  ADD KEY `holidays_created_by_foreign` (`created_by`),
  ADD KEY `holidays_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `leave_requests_master`
--
ALTER TABLE `leave_requests_master`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leave_requests_master_company_id_foreign` (`company_id`),
  ADD KEY `leave_requests_master_requested_by_foreign` (`requested_by`),
  ADD KEY `leave_requests_master_request_updated_by_foreign` (`request_updated_by`);

--
-- Indexes for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leave_types_slug_unique` (`slug`),
  ADD KEY `leave_types_company_id_foreign` (`company_id`),
  ADD KEY `leave_types_created_by_foreign` (`created_by`),
  ADD KEY `leave_types_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `mentioned_comment_members`
--
ALTER TABLE `mentioned_comment_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mentioned_comment_members_mentionable_type_mentionable_id_index` (`mentionable_type`,`mentionable_id`),
  ADD KEY `mentioned_comment_members_member_id_foreign` (`member_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notices_created_by_foreign` (`created_by`),
  ADD KEY `notices_updated_by_foreign` (`updated_by`),
  ADD KEY `notices_company_id_foreign` (`company_id`);

--
-- Indexes for table `notice_receivers`
--
ALTER TABLE `notice_receivers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notice_receivers_notice_id_foreign` (`notice_id`),
  ADD KEY `notice_receivers_notice_receiver_id_foreign` (`notice_receiver_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_created_by_foreign` (`created_by`),
  ADD KEY `notifications_company_id_foreign` (`company_id`),
  ADD KEY `notifications_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `office_times`
--
ALTER TABLE `office_times`
  ADD PRIMARY KEY (`id`),
  ADD KEY `office_times_created_by_foreign` (`created_by`),
  ADD KEY `office_times_updated_by_foreign` (`updated_by`),
  ADD KEY `office_times_company_id_foreign` (`company_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payment_currencies`
--
ALTER TABLE `payment_currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_methods_created_by_foreign` (`created_by`),
  ADD KEY `payment_methods_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`),
  ADD UNIQUE KEY `permissions_permission_key_unique` (`permission_key`),
  ADD KEY `permissions_permission_groups_id_foreign` (`permission_groups_id`);

--
-- Indexes for table `permission_groups`
--
ALTER TABLE `permission_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_groups_group_type_id_foreign` (`group_type_id`);

--
-- Indexes for table `permission_group_types`
--
ALTER TABLE `permission_group_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permission_roles`
--
ALTER TABLE `permission_roles`
  ADD KEY `permission_roles_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_roles_role_id_foreign` (`role_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_dept_id_foreign` (`dept_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `projects_created_by_foreign` (`created_by`),
  ADD KEY `projects_updated_by_foreign` (`updated_by`),
  ADD KEY `projects_client_id_foreign` (`client_id`);

--
-- Indexes for table `project_team_leaders`
--
ALTER TABLE `project_team_leaders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_team_leaders_project_id_foreign` (`project_id`),
  ADD KEY `project_team_leaders_leader_id_foreign` (`leader_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`),
  ADD KEY `roles_created_by_foreign` (`created_by`),
  ADD KEY `roles_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `routers`
--
ALTER TABLE `routers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `routers_branch_id_foreign` (`branch_id`),
  ADD KEY `routers_company_id_foreign` (`company_id`);

--
-- Indexes for table `salary_components`
--
ALTER TABLE `salary_components`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salary_components_created_by_foreign` (`created_by`),
  ADD KEY `salary_components_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `salary_groups`
--
ALTER TABLE `salary_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salary_groups_created_by_foreign` (`created_by`),
  ADD KEY `salary_groups_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `salary_group_component`
--
ALTER TABLE `salary_group_component`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salary_group_component_salary_group_id_foreign` (`salary_group_id`),
  ADD KEY `salary_group_component_salary_component_id_foreign` (`salary_component_id`);

--
-- Indexes for table `salary_group_employees`
--
ALTER TABLE `salary_group_employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salary_group_employees_salary_group_id_foreign` (`salary_group_id`),
  ADD KEY `salary_group_employees_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `salary_t_d_s`
--
ALTER TABLE `salary_t_d_s`
  ADD PRIMARY KEY (`id`),
  ADD KEY `salary_t_d_s_created_by_foreign` (`created_by`),
  ADD KEY `salary_t_d_s_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `supports`
--
ALTER TABLE `supports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supports_created_by_foreign` (`created_by`),
  ADD KEY `supports_updated_by_foreign` (`updated_by`),
  ADD KEY `supports_department_id_foreign` (`department_id`);

--
-- Indexes for table `tadas`
--
ALTER TABLE `tadas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tadas_employee_id_foreign` (`employee_id`),
  ADD KEY `tadas_verified_by_foreign` (`verified_by`),
  ADD KEY `tadas_created_by_foreign` (`created_by`),
  ADD KEY `tadas_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `tada_attachments`
--
ALTER TABLE `tada_attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tada_attachments_tada_id_foreign` (`tada_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_project_id_foreign` (`project_id`),
  ADD KEY `tasks_created_by_foreign` (`created_by`),
  ADD KEY `tasks_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `task_checklists`
--
ALTER TABLE `task_checklists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_checklists_task_id_foreign` (`task_id`),
  ADD KEY `task_checklists_assigned_to_foreign` (`assigned_to`);

--
-- Indexes for table `task_comments`
--
ALTER TABLE `task_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_comments_task_id_foreign` (`task_id`),
  ADD KEY `task_comments_created_by_foreign` (`created_by`);

--
-- Indexes for table `team_meetings`
--
ALTER TABLE `team_meetings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_meetings_company_id_foreign` (`company_id`),
  ADD KEY `team_meetings_created_by_foreign` (`created_by`),
  ADD KEY `team_meetings_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `team_meeting_members`
--
ALTER TABLE `team_meeting_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_meeting_members_team_meeting_id_foreign` (`team_meeting_id`),
  ADD KEY `team_meeting_members_meeting_participator_id_foreign` (`meeting_participator_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_created_by_foreign` (`created_by`),
  ADD KEY `users_updated_by_foreign` (`updated_by`),
  ADD KEY `users_deleted_by_foreign` (`deleted_by`),
  ADD KEY `users_company_id_foreign` (`company_id`),
  ADD KEY `users_branch_id_foreign` (`branch_id`),
  ADD KEY `users_department_id_foreign` (`department_id`),
  ADD KEY `users_supervisor_id_foreign` (`supervisor_id`),
  ADD KEY `users_office_time_id_foreign` (`office_time_id`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_notifications_notification_id_foreign` (`notification_id`),
  ADD KEY `user_notifications_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_settings`
--
ALTER TABLE `app_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `asset_types`
--
ALTER TABLE `asset_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `assigned_members`
--
ALTER TABLE `assigned_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=380;

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `attendances`
--
ALTER TABLE `attendances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=899;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `comment_replies`
--
ALTER TABLE `comment_replies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company_content_management`
--
ALTER TABLE `company_content_management`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee_accounts`
--
ALTER TABLE `employee_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `leave_requests_master`
--
ALTER TABLE `leave_requests_master`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `leave_types`
--
ALTER TABLE `leave_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `mentioned_comment_members`
--
ALTER TABLE `mentioned_comment_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notice_receivers`
--
ALTER TABLE `notice_receivers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `office_times`
--
ALTER TABLE `office_times`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_currencies`
--
ALTER TABLE `payment_currencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `permission_groups`
--
ALTER TABLE `permission_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `permission_group_types`
--
ALTER TABLE `permission_group_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `project_team_leaders`
--
ALTER TABLE `project_team_leaders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `routers`
--
ALTER TABLE `routers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `salary_components`
--
ALTER TABLE `salary_components`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `salary_groups`
--
ALTER TABLE `salary_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `salary_group_component`
--
ALTER TABLE `salary_group_component`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `salary_group_employees`
--
ALTER TABLE `salary_group_employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `salary_t_d_s`
--
ALTER TABLE `salary_t_d_s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `supports`
--
ALTER TABLE `supports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tadas`
--
ALTER TABLE `tadas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tada_attachments`
--
ALTER TABLE `tada_attachments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `task_checklists`
--
ALTER TABLE `task_checklists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `task_comments`
--
ALTER TABLE `task_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `team_meetings`
--
ALTER TABLE `team_meetings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `team_meeting_members`
--
ALTER TABLE `team_meeting_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `assets_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `assets_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `asset_types` (`id`),
  ADD CONSTRAINT `assets_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `asset_types`
--
ALTER TABLE `asset_types`
  ADD CONSTRAINT `asset_types_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `asset_types_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `assigned_members`
--
ALTER TABLE `assigned_members`
  ADD CONSTRAINT `assigned_members_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `attendances`
--
ALTER TABLE `attendances`
  ADD CONSTRAINT `attendances_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `attendances_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `attendances_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `attendances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `branches`
--
ALTER TABLE `branches`
  ADD CONSTRAINT `branches_branch_head_id_foreign` FOREIGN KEY (`branch_head_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `branches_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `branches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `branches_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `clients_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `comment_replies`
--
ALTER TABLE `comment_replies`
  ADD CONSTRAINT `comment_replies_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `task_comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comment_replies_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `companies_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `company_content_management`
--
ALTER TABLE `company_content_management`
  ADD CONSTRAINT `company_content_management_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `company_content_management_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `company_content_management_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  ADD CONSTRAINT `departments_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `departments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `departments_dept_head_id_foreign` FOREIGN KEY (`dept_head_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `departments_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `employee_accounts`
--
ALTER TABLE `employee_accounts`
  ADD CONSTRAINT `employee_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `holidays`
--
ALTER TABLE `holidays`
  ADD CONSTRAINT `holidays_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `holidays_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `holidays_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `leave_requests_master`
--
ALTER TABLE `leave_requests_master`
  ADD CONSTRAINT `leave_requests_master_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `leave_requests_master_request_updated_by_foreign` FOREIGN KEY (`request_updated_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `leave_requests_master_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD CONSTRAINT `leave_types_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `leave_types_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `leave_types_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `mentioned_comment_members`
--
ALTER TABLE `mentioned_comment_members`
  ADD CONSTRAINT `mentioned_comment_members_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `notices`
--
ALTER TABLE `notices`
  ADD CONSTRAINT `notices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `notices_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `notices_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `notice_receivers`
--
ALTER TABLE `notice_receivers`
  ADD CONSTRAINT `notice_receivers_notice_id_foreign` FOREIGN KEY (`notice_id`) REFERENCES `notices` (`id`),
  ADD CONSTRAINT `notice_receivers_notice_receiver_id_foreign` FOREIGN KEY (`notice_receiver_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `notifications_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `notifications_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `office_times`
--
ALTER TABLE `office_times`
  ADD CONSTRAINT `office_times_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `office_times_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `office_times_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `payment_methods_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `payment_methods_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_permission_groups_id_foreign` FOREIGN KEY (`permission_groups_id`) REFERENCES `permission_groups` (`id`);

--
-- Constraints for table `permission_groups`
--
ALTER TABLE `permission_groups`
  ADD CONSTRAINT `permission_groups_group_type_id_foreign` FOREIGN KEY (`group_type_id`) REFERENCES `permission_group_types` (`id`);

--
-- Constraints for table `permission_roles`
--
ALTER TABLE `permission_roles`
  ADD CONSTRAINT `permission_roles_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `permission_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_dept_id_foreign` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `projects_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `projects_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `project_team_leaders`
--
ALTER TABLE `project_team_leaders`
  ADD CONSTRAINT `project_team_leaders_leader_id_foreign` FOREIGN KEY (`leader_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `project_team_leaders_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `roles_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `routers`
--
ALTER TABLE `routers`
  ADD CONSTRAINT `routers_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  ADD CONSTRAINT `routers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`);

--
-- Constraints for table `salary_components`
--
ALTER TABLE `salary_components`
  ADD CONSTRAINT `salary_components_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `salary_components_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `salary_groups`
--
ALTER TABLE `salary_groups`
  ADD CONSTRAINT `salary_groups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `salary_groups_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `salary_group_component`
--
ALTER TABLE `salary_group_component`
  ADD CONSTRAINT `salary_group_component_salary_component_id_foreign` FOREIGN KEY (`salary_component_id`) REFERENCES `salary_components` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `salary_group_component_salary_group_id_foreign` FOREIGN KEY (`salary_group_id`) REFERENCES `salary_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `salary_group_employees`
--
ALTER TABLE `salary_group_employees`
  ADD CONSTRAINT `salary_group_employees_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `salary_group_employees_salary_group_id_foreign` FOREIGN KEY (`salary_group_id`) REFERENCES `salary_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `salary_t_d_s`
--
ALTER TABLE `salary_t_d_s`
  ADD CONSTRAINT `salary_t_d_s_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `salary_t_d_s_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `supports`
--
ALTER TABLE `supports`
  ADD CONSTRAINT `supports_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `supports_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `supports_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `tadas`
--
ALTER TABLE `tadas`
  ADD CONSTRAINT `tadas_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tadas_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tadas_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tadas_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `tada_attachments`
--
ALTER TABLE `tada_attachments`
  ADD CONSTRAINT `tada_attachments_tada_id_foreign` FOREIGN KEY (`tada_id`) REFERENCES `tadas` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tasks_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tasks_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `task_checklists`
--
ALTER TABLE `task_checklists`
  ADD CONSTRAINT `task_checklists_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `task_checklists_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `task_comments`
--
ALTER TABLE `task_comments`
  ADD CONSTRAINT `task_comments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `task_comments_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `team_meetings`
--
ALTER TABLE `team_meetings`
  ADD CONSTRAINT `team_meetings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `team_meetings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `team_meetings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `team_meeting_members`
--
ALTER TABLE `team_meeting_members`
  ADD CONSTRAINT `team_meeting_members_meeting_participator_id_foreign` FOREIGN KEY (`meeting_participator_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `team_meeting_members_team_meeting_id_foreign` FOREIGN KEY (`team_meeting_id`) REFERENCES `team_meetings` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  ADD CONSTRAINT `users_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `users_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `users_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `users_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `users_office_time_id_foreign` FOREIGN KEY (`office_time_id`) REFERENCES `office_times` (`id`),
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `users_supervisor_id_foreign` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `users_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD CONSTRAINT `user_notifications_notification_id_foreign` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
